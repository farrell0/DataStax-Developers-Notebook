

#  Small Web UI program to demonstrate calculating shortest
#  path using DSE Graph.
#
#  Imagine a (maze) that looks similar to,
#
#                           Finish
#          C1    C2    C3    C4    C5
#        +-----+-----+-----+-----+-----+
#        |     .     .     .     .     |
#     R1 |                             |
#        +  .  +  .  +-----+  .  +  .  +
#        |     .     |     |     .     |
#     R2 |           |     |           |
#        +  .  +-----+-----+-----+-----+
#        |     .     .     .     .     |
#     R3 |                             |
#        +  .  +  .  +-----+  .  +  .  +
#        |     . Must|     .     .     |
#     R4 |       Have|     .           |
#        +  .  +  .  +  .  +  .  +  .  +
#        |     .     |     .     .     |
#     R5 |           |                 |
#        +-----+-----+-----+-----+-----+
#                           Start
#
#
#  This program allows you to select/deselect walls
#  that change the (maze). A DSE Graph query answers
#  the question; How do you get from Start to Finish.
#
#  There is also an assignable (must have) square.
#
#     So when we move to airline routing; you want
#     to go from SFO to JFK, but you want to go
#     thru IAH type of thing.
#
#  Our program maze is larger, and starts with no 
#  walls. Our program maze has one start and two
#  exits.


#  In the Web UI, 
#
#     .  Click on 'walls' to select/deselect, causing a
#        change in the available (shortest path)
#
#     .  Click on 1 special 'must have' square, a (square)
#        that the solution must pass thru
#
#        Lack of robustness in the UI; if you don't want a
#        'must have' square, then place this right next to
#        any entrance/exit to make its effect (null)


#  Need the DSE 6.8 Python drivers,
#     pip install dse-driver-2.9.0.20190711+labs.tar.gz
#     pip install dse-graph-1.7.0.20190711+labs.tar.gz
#
#  Using the Python driver,
#     https://docs.datastax.com/en/developer/python-driver/3.20/getting_started/#asynchronous-queries
#     https://docs.datastax.com/en/developer/python-driver-dse/2.11/graph/

#  In the dse.yaml,
#     realtime_evaluation_timeout_in_seconds: 30   <--  set to 60
#     client_request_timeout_seconds: 60           <--  set to 60




############################################################


#
#  Imports
#

import os, json

from flask import Flask, request, render_template, jsonify

#
#  Disable every get server request notification via logging
#  level-
#
import logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

from dse.cluster import Cluster, GraphExecutionProfile
from dse.cluster import EXEC_PROFILE_GRAPH_DEFAULT
from dse.cluster import EXEC_PROFILE_GRAPH_ANALYTICS_DEFAULT
   #
from dse.graph import GraphOptions, GraphProtocol, graph_graphson3_row_factory




############################################################
############################################################


#
#  The Web site
#

m_webApp = Flask(__name__)

m_templateDir = os.path.abspath("45_views" )
m_staticDir   = os.path.abspath("44_static")
   #
m_webApp.template_folder = m_templateDir
m_webApp.static_folder   = m_staticDir

        ####################################

#
#  Specific to this application; modular variables
#
m_mustHaveSquare = { "row" : 19, "col" : 11 }

        ####################################

#
#  Assuming a DSE at localhost with DSE Search and Graph
#  are turned on
#
l_graphName = 'ks_33'


l_execProfile1 = GraphExecutionProfile(                  # OLTP
   graph_options=GraphOptions(graph_name=l_graphName,
      graph_protocol=GraphProtocol.GRAPHSON_3_0),
      row_factory=graph_graphson3_row_factory
   )
l_execProfile2 = GraphExecutionProfile(                  # OLAP
   graph_options=GraphOptions(graph_name=l_graphName,
      graph_source='a',
      graph_protocol=GraphProtocol.GRAPHSON_3_0),
      row_factory=graph_graphson3_row_factory
   )

l_cluster = Cluster(execution_profiles = {
   EXEC_PROFILE_GRAPH_DEFAULT:           l_execProfile1,
   EXEC_PROFILE_GRAPH_ANALYTICS_DEFAULT: l_execProfile2},
   contact_points=['127.0.0.1']
   )
m_session = l_cluster.connect()




############################################################
############################################################


#
#  The server side Web page handlers; initial load
#  and process client side events.
#


@m_webApp.route("/")
def index():
   return render_template("60_index.html")


@m_webApp.route("/_do_server")
def do_server():

   #  Event procesing from the client side. Events
   #  include,
   #
   #     move-square
   #     deselect-line
   #     select-line

   #  Comes as string, convert to dictionary
   #
   l_click  = json.loads(request.args.get("h_click"))

   #  Process the client side event,
   #     Update m_mustHaveSquare 
   #     And make writes to the database edge table
   #
   event_process(l_click)

   #  Get the graph shortest path response via
   #  a Gremlin query. We only do thids when the
   #  (must have square) has changed.
   #
   if   (l_click["event"] == "move-square"  ):  
      l_returnPath = calculate_path()
   else:
      l_returnPath = []


   return jsonify(l_returnPath)




############################################################
############################################################


#
#  Event processing from the client side. Events include,
#
#     move-square
#     deselect-line
#     select-line
#

def event_process(i_args):
   global m_mustHaveSquare
      #
   global m_session
   global m_ins2
   global m_del1

      #############################################

   i_event = i_args["event"]
   i_row   = i_args["row"  ]
   i_col   = i_args["col"  ]

   if   (i_event == "move-square"  ):  

      #  Record the 'must have square'
      #
      m_mustHaveSquare = { "row" : i_row, "col" : i_col }
         
      print ""
      print "Client side event: New 'Must Have Square', (" + \
         str(i_row) + ", " + str(i_col) + ")"

   elif (i_event == "select-line"  ):  

      #
      #  Selecting a line equals deleting an edge
      # 
      #  If the row is odd , this is a horizontal edge  <--> 
      #  If the row is even, this is a vertical   edge
      #
      if (i_row % 2 == 1):
         l_row_src = i_row 
         l_col_src = i_col - 1
         l_row_dst = i_row
         l_col_dst = i_col + 1
      else:
         l_row_src = i_row - 1
         l_col_src = i_col
         l_row_dst = i_row + 1
         l_col_dst = i_col
            #
      l_sq_src = "x" + str(l_row_src) + "-" + str(l_col_src)
      l_sq_dst = "x" + str(l_row_dst) + "-" + str(l_col_dst)
         #
      l_rows = m_session.execute(m_del1, [ l_sq_src, l_sq_dst ])
      l_rows = m_session.execute(m_del1, [ l_sq_dst, l_sq_src ])
         #
      print ""
      print "DELETE EDGE instance: " + l_sq_src + ", " + l_sq_dst
      print "DELETE EDGE instance: " + l_sq_dst + ", " + l_sq_src
      print ""
      
   elif (i_event == "deselect-line"):  

      #
      #  Deselecting a line equals inserting an edge
      # 
      #  If the row is odd , this is a horizontal edge  <--> 
      #  If the row is even, this is a vertical   edge
      #
      if (i_row % 2 == 1):
         l_row_src = i_row
         l_col_src = i_col - 1
         l_row_dst = i_row
         l_col_dst = i_col + 1
      else:
         l_row_src = i_row - 1
         l_col_src = i_col
         l_row_dst = i_row + 1
         l_col_dst = i_col
            #
      l_sq_src = "x" + str(l_row_src) + "-" + str(l_col_src)
      l_sq_dst = "x" + str(l_row_dst) + "-" + str(l_col_dst)
         #
      l_rows = m_session.execute(m_ins2, [ l_sq_src, l_sq_dst ])
      l_rows = m_session.execute(m_ins2, [ l_sq_dst, l_sq_src ])
         #
      print ""
      print "INSERT EDGE instance: " + l_sq_src + ", " + l_sq_dst
      print "INSERT EDGE instance: " + l_sq_dst + ", " + l_sq_src
      print ""
   
   else: 

      print ""
      print "ERROR 7442: 60_GridPlusAjax.py/_do_server/event_process"
      print "  Received an event we're not programmed for.        "
      print "  ( " + i_event + " )"




############################################################
############################################################


#
#  Where above is our client side event processing,
#  this function only manages the execution of the
#  graph traversal
#

def calculate_path():
   global m_mustHaveSquare
      #
   global m_session

   l_returnPath = []


   l_row = m_mustHaveSquare["row"]
   l_col = m_mustHaveSquare["col"]
      #
   l_sq  = "x" + str(l_row) + "-" + str(l_col)

   #
   #  These lines returned 3 (count) dummy squares when
   #  we had/have no Gremlin traversal to calculate the
   #  shortest path for us.
   #
   # l_testStr  = "x" + str(l_row) + "-" + str(l_col + 2)
   # l_someStep = { "square" : l_testStr }
   # l_returnPath.append(l_someStep)
   #    #
   # l_testStr  = "x" + str(l_row) + "-" + str(l_col + 4)
   # l_someStep = { "square" : l_testStr }
   # l_returnPath.append(l_someStep)
   #    #
   # l_testStr  = "x" + str(l_row) + "-" + str(l_col + 6)
   # l_someStep = { "square" : l_testStr }
   # l_returnPath.append(l_someStep)
   #
   #  Sample return data format below,
   #
   #     [{'square': 'x19-13'}, {'square': 'x19-15'}, {'square': 'x19-17'}]
   #

   l_stmt =                                                    \
      "g.V()                                               " + \
      "   .has('grid_square', 'square_id', 'x21-11')       " + \
      "   .repeat(                                         " + \
      "      out('connects_to')                            " + \
      "      .dedup()                                      " + \
      "   )                                                " + \
      "   .until(                                          " + \
      "      has('square_id', '" + l_sq + "')              " + \
      "   )                                                " + \
      "   .path()                                          " + \
      "   .project('path')                                 " + \
      "      .by(                                          " + \
      "         unfold()                                   " + \
      "         .values('square_id')                       " + \
      "         .fold()                                    " + \
      "      )                                             " + \
      "   .next()                                          "
         #
   l_stmt2 = ' '.join(l_stmt.split())
   print ""
   print "Gremlin Traversal 1: " + l_stmt2
   print ""
      #
   try:
      l_data = m_session.execute_graph(l_stmt, 
         execution_profile=EXEC_PROFILE_GRAPH_DEFAULT )[0]
      l_arra = l_data["path"]
         #
      for l_elem in l_arra:
         l_dict = { "square" : l_elem.encode('ascii', 'ignore')}
         l_returnPath.append(l_dict)
   except:
      print "   (No path found, or traversal timeout reached.)"

   l_stmt =                                                    \
      "g.V()                                               " + \
      "   .has('grid_square', 'square_id', '"                + \
      l_sq + "')                                           " + \
      "   .repeat(                                         " + \
      "      out('connects_to')                            " + \
      "      .dedup()                                      " + \
      "   )                                                " + \
      "   .until(                                          " + \
      "      has('square_id', 'x7-1')                      " + \
      "      .or()                                         " + \
      "      .has('square_id', 'x1-21')                    " + \
      "   )                                                " + \
      "   .path()                                          " + \
      "   .project('path')                                 " + \
      "      .by(                                          " + \
      "         unfold()                                   " + \
      "         .values('square_id')                       " + \
      "         .fold()                                    " + \
      "      )                                             " + \
      "   .next()                                          "
         #
   l_stmt2 = ' '.join(l_stmt.split())
   print ""
   print "Gremlin Traversal 2: " + l_stmt2
   print ""
      #
   try:
      l_data = m_session.execute_graph(l_stmt, 
         execution_profile=EXEC_PROFILE_GRAPH_DEFAULT )[0]
      l_arra = l_data["path"]
         #
      for l_elem in l_arra:
         l_dict = { "square" : l_elem.encode('ascii', 'ignore')}
         l_returnPath.append(l_dict)
   except:
      print "   (No path found, or traversal timeout reached.)"

   return l_returnPath




############################################################
############################################################


#
#  Create the DSE server side objects; keyspace, table,
#  indexes, ..
#

def init_db1():
   global m_session


   print ""
   print ""

   l_stmt =                                                    \
      "DROP KEYSPACE IF EXISTS ks_33;                      "
         #
   l_rows = m_session.execute(l_stmt)
      #
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Drop Keyspace: " + l_stmt2


   l_stmt =                                                    \
      "CREATE KEYSPACE ks_33                               " + \
      "   WITH replication = {'class': 'SimpleStrategy',   " + \
      "      'replication_factor': 1}                      " + \
      "   AND graph_engine = 'Core';                       " + \
      "                                                    " 
         #
   l_rows = m_session.execute(l_stmt)
      #
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Create Keyspace: " + l_stmt2


   l_stmt =                                                    \
      "CREATE TABLE ks_33.grid_square                      " + \
      "   (                                                " + \
      "   square_id            TEXT,                       " + \
      "   PRIMARY KEY((square_id))                         " + \
      "   )                                                " + \
      "WITH VERTEX LABEL grid_square                       " + \
      ";                                                   "
         #
   l_rows = m_session.execute(l_stmt)
      #
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Create Vertex: " + l_stmt2


   l_stmt =                                                    \
      "CREATE SEARCH INDEX ON ks_33.grid_square            " + \
      "   WITH COLUMNS square_id { docValues : true };     "
         #
   l_rows = m_session.execute(l_stmt)
      #
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Create Search Index: " + l_stmt2


   l_stmt =                                                    \
      "CREATE TABLE ks_33.connects_to                      " + \
      "   (                                                " + \
      "   square_id_src        TEXT,                       " + \
      "   square_id_dst        TEXT,                       " + \
      "   PRIMARY KEY((square_id_src), square_id_dst)      " + \
      "   )                                                " + \
      "WITH EDGE LABEL connects_to                         " + \
      "   FROM grid_square(square_id_src)                  " + \
      "   TO   grid_square(square_id_dst);                 " 
         #
   l_rows = m_session.execute(l_stmt)
      #
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Create Edge: " + l_stmt2


   l_stmt =                                                    \
      "CREATE MATERIALIZED VIEW ks_33.connects_to_bi       " + \
      "   AS SELECT square_id_src, square_id_dst           " + \
      "   FROM connects_to                                 " + \
      "   WHERE                                            " + \
      "      square_id_src IS NOT NULL                     " + \
      "   AND                                              " + \
      "      square_id_dst IS NOT NULL                     " + \
      "   PRIMARY KEY ((square_id_dst), square_id_src);    "
         #
   l_rows = m_session.execute(l_stmt)
      #
   print ""
   l_stmt2 = ' '.join(l_stmt.split())
   print "Create Bi-direction to Edge: " + l_stmt2




############################################################


#
#  Load the Vertex and Edge with starter data
#

def init_db2():
   global m_session
   global m_ins2


   l_squares = [ 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21 ]


   #
   #  Insert data into the vertex; ks_33.grid_squares
   #
   l_ins1 = m_session.prepare(
      "INSERT INTO ks_33.grid_square (square_id) VALUES ( ? )"
      )
   for r in l_squares:
      for c in l_squares:
         l_data = "x" + str(r) + "-" + str(c)
         l_rows = m_session.execute(l_ins1, [ l_data ])


   #
   #  Insert data into the edge; ks_33.connects_to
   #
   for r in l_squares:
      for c in l_squares:
         #
         #  Within 1 row; column current <---> column right
         #
         if (c < 21):
            l_left_ = "x" + str(r) + "-" + str(c    )
            l_right = "x" + str(r) + "-" + str(c + 2)
               #
            l_rows = m_session.execute(m_ins2, [ l_left_, l_right ] )
            l_rows = m_session.execute(m_ins2, [ l_right, l_left_ ] )

         #
         # Within 1 column; row current to row below
         #
         if (r < 21):
            l_above = "x" + str(r    ) + "-" + str(c)
            l_below = "x" + str(r + 2) + "-" + str(c)
               #
            l_rows = m_session.execute(m_ins2, [ l_above, l_below ] )
            l_rows = m_session.execute(m_ins2, [ l_below, l_above ] )

   #
   #  From the loops above, we end up missing the bottom,
   #  right-most square. Do manually ..
   #
   l_rows = m_session.execute(m_ins2, [ "x19-21", "x21-21" ] )
   l_rows = m_session.execute(m_ins2, [ "x21-21", "x19-21" ] )
   l_rows = m_session.execute(m_ins2, [ "x21-19", "x21-21" ] )
   l_rows = m_session.execute(m_ins2, [ "x21-21", "x21-19" ] )




############################################################
############################################################


#
#  Our program proper
#

if __name__=='__main__':
   
   init_db1()

   #
   #  Our prepared INSERT(s) and DELETE(s)
   #
   m_ins2 = m_session.prepare(
      "INSERT INTO ks_33.connects_to (square_id_src, " + \
      "   square_id_dst) VALUES ( ?, ? )             "
      )
   m_del1 = m_session.prepare(
      "DELETE FROM ks_33.connects_to WHERE           " + \
      "   square_id_src = ? AND square_id_dst = ?    "
      )

   init_db2()
   
   print ""
   print ""
   print "Web app running at:  localhost:8081"
   print ""
      #
   m_webApp.run(host = "localhost", port = int("8081"), debug=True)




####################################











