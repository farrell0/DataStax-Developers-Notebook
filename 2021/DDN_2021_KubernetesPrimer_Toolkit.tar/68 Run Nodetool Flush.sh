#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""
echo "Use 'kubectl' to run nodetool flush against all C* nodes."
echo ""
echo ""

l_nodes=`kubectl get pods -n ${MY_NS_CASS} | egrep -v "NAME|${MY_NS_CASS}-" | awk '{print $1}'`

for l_node in ${l_nodes}
   do
   echo "Running from node: "${l_node}
   kubectl -n ${MY_NS_CASS} exec -it -c cassandra ${l_node} -- nodetool flush
   echo ""
   echo ""
done








