#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""

gcloud container clusters list

echo ""
echo ""

