#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""

kubectl get pv

echo ""
echo ""

kubectl -n ${MY_NS_CASS} get pvc

echo ""
echo ""





