#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to apply the Cassandra Operator YAML file ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
echo "   Right now:"
echo "      D1 - makes the first C* cluster, 1 node"
echo "      D2 - shuts down D1"
echo "      D8 - similar to D1, but makes a second C* cluster"
echo "      D9 - shuts down D8"
echo ""
echo "      D4 - D1, with 3 nodes"
echo "      D5 - D1, with 2 nodes"
echo ""
echo "Edit the given YAML file if you have specific changes you want made."
echo ""
sleep 10


echo ""
echo ""
echo -n "Enter the YAML file number to apply (default is D1): "
   #
[ ${#} -gt 0 ] && {
   l_numb=${1}
} || {
   read l_numb
}
   #
[ -z ${l_numb} ] && {
   l_numb=D1
}


##############################################################


echo ""
echo ""

kubectl -n ${MY_NS_CASS} apply -f ${l_numb}*


echo ""
echo ""
echo "Next steps:  (if this is a net new C* cluster)"
echo ""
echo "   watch kubectl -n cass-operator get pods"
echo ""
echo "   Look for all pods 'Running'"
echo "   Example:"
echo "      cluster1-system1-default-sts-0   2/2     Running   0          2m38s"
echo ""
echo ""









