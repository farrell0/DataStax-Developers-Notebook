#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""
echo "Use 'kubectl' to run cqlsh(C) from a random C* pod."
echo ""
echo ""

#  Data looks similar to,
#
#    cass-operator   cass-operator-55ddb95c99-f7ws7                              1/1     Running   0          48m
#    cass-operator   cluster2-system2-default-sts-0                              2/2     Running   0          36m
#
#  Use kubectl to get the 2nd line, 2nd word prefix

l_UserName=`kubectl get pods --namespace=${MY_NS_CASS} --no-headers | awk '{print $1}' | grep -v ${MY_NS_CASS} | head -1 | cut -f1,1 -d'-'`-superuser
   #
CASS_USER=$(kubectl -n ${MY_NS_CASS} get secret ${l_UserName} -o json | grep -A2 '"data": {' | grep '"username":' | awk '{print$2}' | sed 's/"//' | base64 --decode 2> /dev/null)
CASS_PASS=$(kubectl -n ${MY_NS_CASS} get secret ${l_UserName} -o json | grep -A2 '"data": {' | grep '"password":' | awk '{print$2}' | sed 's/"//' | base64 --decode 2> /dev/null)


#  shuf(C) generates a random number-
#
#  Why we're doing this;  Any given node may be down.

l_num_nodes=`kubectl get pods -n ${MY_NS_CASS} | egrep -v "NAME|${MY_NS_CASS}-" | wc -l`
l_which_node=`shuf -i 1-${l_num_nodes} -n 1`
   #
l_node=`kubectl get pods -n ${MY_NS_CASS} | egrep -v "NAME|${MY_NS_CASS}-" | sed ${l_which_node}'!d' | awk '{print $1}'`


kubectl -n ${MY_NS_CASS} exec -ti ${l_node} -c cassandra -- sh -c "cqlsh -u '$CASS_USER' -p '$CASS_PASS'"


echo ""
echo ""


