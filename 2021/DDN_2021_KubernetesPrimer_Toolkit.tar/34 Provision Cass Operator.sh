#!/bin/bash


#    https://github.com/datastax/cass-operator
# 
#    Need this level of permission;
#       container.roleBindings.create
# 
#       //   gcloud projects add-iam-policy-binding ${GKE_PROJECT} \
#       //     --member=user:daZZZZZZZZZZZZZZZZZZZZx.com \
#       //     --role=roles/container.admin
#       //   
#       //   Without correction above, get a,
#       //   
#       //      40 below errors with
#       //         namespace/cass-operator created
#       //         serviceaccount/cass-operator created
#       //         secret/cass-operator-webhook-config created
#       //         customresourcedefinition.apiextensions.k8s.io/cassandradatacenters.cassandra.datastax.com created
#       //         service/cassandradatacenter-webhook-service created
#       //         deployment.apps/cass-operator created
#       //         validatingwebhookconfiguration.admissionregistration.k8s.io/cassandradatacenter-webhook-registration created
#       //         Error from server (Forbidden): error when creating "40_cass-operator-manifests-v1.16.yaml":
#       //            clusterroles.rbac.authorization.k8s.io is forbidden: User "daZZZZZZZZZZZZZZZZZZZax.com"
#       //            cannot create resource "clusterroles" in API group "rbac.authorization.k8s.io" at the
#       //            cluster scope: requires one of ["container.clusterRoles.create"] permission(s).
#       //               ... 


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to provision DataStax Cassandra Kubernetes Operator version 1.5 ..."
echo "   (And make expected storage classes.)"
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
sleep 10


kubectl create -f C1_cass-operator-manifests-v1.17.yaml
echo ""
kubectl create -f C2_storage.yaml
kubectl apply  -f C3_CreateVolumeSnapshotClass.yaml


echo ""
echo ""





