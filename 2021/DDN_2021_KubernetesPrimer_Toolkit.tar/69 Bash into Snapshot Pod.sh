#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to Bash into our data/snapshot Pod ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
echo ""
sleep 10


##############################################################


echo "Next steps:"
echo ""
echo "   . /root/.bashrc"
echo "   cd /opt2"
echo ""
echo ""


kubectl -n ${MY_NS_USER}  exec -it  snapshot-data-pod --  bash



