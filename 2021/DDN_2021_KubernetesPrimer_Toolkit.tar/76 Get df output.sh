#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to 'df -k' into Cassandra nodes ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
sleep 10


##############################################################


#  Data looks like,
#     
#     df
#        Filesystem     1K-blocks  Used Available Use% Mounted on
#        overlay          1003743  3774    999954   1% /
#        tmpfs                 64     0        64   0% /dev
#        tmpfs              16087     0     16087   0% /sys/fs/cgroup
#        /dev/sda1        1003743  3774    999954   1% /config
#        tmpfs              16087     1     16087   1% /etc/encryption
#        shm                   64     0        64   0% /dev/shm
#        /dev/sdb            4976    23      4937   1% /var/lib/cassandra
#        tmpfs              16087     1     16087   1% /run/secrets/kubernetes.io/serviceaccount
#        tmpfs              16087     0     16087   0% /proc/acpi
#        tmpfs              16087     0     16087   0% /proc/scsi
#        tmpfs              16087     0     16087   0% /sys/firmware


echo ""
echo "C*-Node/K8s-Pod                   Filesystem          Size-GB     Used-GB     Available   Use%  Mounted on"
echo "================================  ==================  ==========  ==========  ==========  ====  ===================="
   #
for l_node in `kubectl --namespace=${MY_NS_CASS} get pods | egrep -v "NAME|${MY_NS_CASS}-" | awk '{print $1}'`
   do

   kubectl --namespace=${MY_NS_CASS} exec -it ${l_node} df 2> /dev/null | \
      grep "^${MY_WHICH_FS}" | awk -v l_node=${l_node} '
         {
         printf("%-32s  %-18s  %-10.2f  %-10.2f  %-10.2f  %4s  %s\n", l_node, $1, $2/1024/1024, $3/1024/1024, $4/1024/1024, $5, $6);
         }'
   
   done

echo ""
echo ""




