#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""
echo "This program gets the Cassandra logs from a given Cassandra node (1-N)."
echo ""
echo "(Similar to a 'tail -f', press Control-C to terminate output.)"
echo ""


l_cass_pods=$(kubectl get pods --namespace=${MY_NS_CASS} --no-headers | awk '{print $1}' | grep -v ${MY_NS_CASS})
l_cntr=0

for l_node in ${l_cass_pods}
   do
   l_cntr=$((l_cntr+1))
   echo "  "${l_cntr}":  "${l_node}
   done
      
echo ""
echo ""
echo -n "Enter the node number to get Cassandra logs from: "
   #
read l_numb
   #
[ -z ${l_numb} ] && {
   l_numb=0
}


l_cntr=0

for l_node in ${l_cass_pods}
   do
   l_cntr=$((l_cntr+1))
      #
   [ ${l_cntr} -eq ${l_numb} ] && {

      kubectl logs -f --namespace=${MY_NS_CASS} ${l_node} -c server-system-logger
      
   } || {
      :
   }
   done

echo ""
echo ""





