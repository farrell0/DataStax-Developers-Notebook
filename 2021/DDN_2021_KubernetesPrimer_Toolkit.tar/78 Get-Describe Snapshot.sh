#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""

kubectl -n ${MY_NS_CASS} get volumesnapshot

echo ""
echo ""

kubectl -n ${MY_NS_CASS} describe volumesnapshot

echo ""
echo ""





