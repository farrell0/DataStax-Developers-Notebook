#!/bin/bash


#  From,
#     https://kubernetes.io/docs/tasks/run-application/force-delete-stateful-set-pod/


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to kill the last position Cassandra node ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
echo ""
echo "Ps: if you pass any command line argument, the node is flushed before it is killed."
echo ""
echo ""
sleep 10


l_node=`kubectl --namespace=${MY_NS_CASS} get pods | tail -1 | awk '{print $1}'`

[ ${#} -gt 0 ] && {
   kubectl --namespace=${MY_NS_CASS} exec -it ${l_node} "nodetool flush"
} || {
   :
}


kubectl --namespace=${MY_NS_CASS} delete pods ${l_node} --grace-period=0 --force


echo ""
echo ""





