#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""

kubectl get pods -A

echo ""
echo ""




