#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""

kubectl get sc

echo ""
echo ""

kubectl describe sc

echo ""
echo ""




