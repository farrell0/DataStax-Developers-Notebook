#!/bin/bash


#
#  This file is sourced from most programs in this folder; 
#  variables used throughout
#


alias kc=kubectl

GKE_PROJECT=gke-launcher-dev
GKE_ZONE=us-central1-a
   #
MY_CLUSTER=farrell-cluster

MY_NS_OPERATOR=ns-cass-operator
   #
MY_NS_CCLUSTER1=ns-cass-sys1
MY_NS_CCLUSTER2=ns-cass-sys2
   #
MY_NS_USER1=ns-user1
MY_NS_USER2=ns-user2

MY_BUCKET=farrell-gcs-bucket


