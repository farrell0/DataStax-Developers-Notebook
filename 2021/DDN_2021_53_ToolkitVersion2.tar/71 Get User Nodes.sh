#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""

kubectl get nodes -A       #  --all-namespaces

echo ""
echo ""


