

CASS_USER=cluster1-superuser
CASS_PASS=U-k4DrK_jYWNydkELnheqLzuOV3JfrntIRsuBCFE8CO9ECXI6tR-fw

IP_LIST=10.28.0.7

export PATH=${PATH}:/opt/cassandra/bin
export PATH=${PATH}:/opt/cassandra/tools/bin
export PATH=${PATH}:/usr/lib/jvm/java-11-openjdk-amd64/bin
export PATH=${PATH}:.




