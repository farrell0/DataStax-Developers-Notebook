#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""
echo "Use 'kubectl' to run cqlsh(C) from a random C* pod."
echo "   (This program makes a random choice from the first C* namespace, with any active pods.)"
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
echo ""
sleep 10


kubectl get pods -A | egrep "${MY_NS_CCLUSTER1}|${MY_NS_CCLUSTER2}" 
echo ""
echo ""


l_ns=`kubectl get pods -A | egrep "${MY_NS_CCLUSTER1}|${MY_NS_CCLUSTER2}" | awk '{print $1}' | head -1`
l_UserName=`kubectl -n ${l_ns} get pods --no-headers | awk '{print $1}' | head -1 | cut -f1,1 -d'-'`-superuser
   #
CASS_USER=$(kubectl -n ${l_ns} get secret ${l_UserName} -o json | grep -A2 '"data": {' | grep '"username":' | awk '{print$2}' | sed 's/"//' | base64 --decode 2> /dev/null)
CASS_PASS=$(kubectl -n ${l_ns} get secret ${l_UserName} -o json | grep -A2 '"data": {' | grep '"password":' | awk '{print$2}' | sed 's/"//' | base64 --decode 2> /dev/null)


#  shuf(C) generates a random number-
#
#  Why we're doing this;  Any given node may be down.

l_num_nodes=`kubectl get pods -n ${l_ns} --no-headers | wc -l`
l_which_node=`shuf -i 1-${l_num_nodes} -n 1`
   #
l_node=`kubectl get pods -n ${l_ns} --no-headers | sed ${l_which_node}'!d' | awk '{print $1}'`


echo "Running against: ${l_ns}/${l_node}"
echo "   Username: ${CASS_USER}"
echo "   Password: ${CASS_PASS}"
echo ""
echo ""
   #
kubectl -n ${l_ns} exec -ti ${l_node} -c cassandra -- sh -c "cqlsh -u '$CASS_USER' -p '$CASS_PASS'"


echo ""
echo ""





