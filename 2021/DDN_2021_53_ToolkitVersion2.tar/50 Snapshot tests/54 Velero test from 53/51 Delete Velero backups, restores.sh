#!/bin/bash


# . "./20 Defaults.sh"


##############################################################


echo ""
echo ""
echo "Calling 'velero' to delete any previous Velero backup or restore images ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
echo ""
sleep 10

velero delete backup  --all --confirm
velero delete restore --all --confirm

echo ""
echo ""




