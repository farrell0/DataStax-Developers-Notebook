

import "./App.css"
   //
import { useEffect, useState } from "react"
   //
import NavBar from "./components/NavBar"
import HeroSection from "./components/HeroSection"
import Top10 from "./components/Top10"
import Section from "./components/Section"
   //
import { getTop10, getGenres } from "./utils/Api"


// ///////////////////////////////////////////////////////


const App = () => {
  const [genres, setGenres] = useState(null)
  const [top10, setTop10]   = useState([])

  const fetchData = async () => {
    const genres = await getGenres()
    setGenres(genres)

    const initTop10 = await getTop10()
    setTop10(initTop10)
  }

  useEffect(() => {
    fetchData()
  }, [])

  //  This area presents the 4 components displayed on our home page.
  //

  return (

    <>

    <NavBar />
    <HeroSection />
    <Top10 top10={top10} />

    {genres && (
      <div className="container">
        {Object.values(genres).map((genre, index) => (
          <Section key={index} genre={genre.value} setTop10={setTop10} />
        ))}
      </div>
    )}

    </>
    )
  }


export default App



