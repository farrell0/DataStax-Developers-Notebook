

export async function saveEvent(payload) {
    const res = await fetch('/.netlify/functions/updateTop10', {
        method: 'POST',
        body: JSON.stringify(payload)
    });
    console.log(res);
    return res;
}

export async function getTop10() {
    const res = await fetch('/.netlify/functions/getTop10')
    const resJson = await res.json();
    console.log(resJson);
    return resJson;
}

export async function getGenres() {
    const res = await fetch("/.netlify/functions/getGenresV2")
      const resJson = await res.json();
      console.log(resJson);
      return resJson.data.reference_list.values;
}