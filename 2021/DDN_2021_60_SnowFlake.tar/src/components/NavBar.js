

//  Our first of four components on our home page; really
//  just some labels

const NavBar = () => {
    return (
      <div className="navbar">
        <ul>
          <li>
            <div className="logo"></div>
          </li>
          <li>
            <a href="/">
               DataStax-Astra/Apache-Cassandra
            </a>
          </li>
          <li>
            <a href="/">
               SnowFlake
            </a>
          </li>
        </ul>
      </div>
    )
  }
  
  export default NavBar



