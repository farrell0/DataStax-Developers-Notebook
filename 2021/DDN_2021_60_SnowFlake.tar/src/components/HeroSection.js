

//  This second of four components on our home page. Really we're
//  just splashing a movie on the page for visual excitement

const HeroSection = () => {

  return (
    <>
      <div className="hero">

        <video className="hero-video" muted controls autoPlay={true} loop>
          <source src="https://i.imgur.com/QzJe4nJ.mp4" type="video/mp4" />
        </video>

        <div className="info-section">
          <h3 className="hero-blurb">
            "When a beautiful stranger leads computer hacker Neo to a forbidding underworld, he discovers the shocking truth--the life he knows is the elaborate deception of an evil cyber-intelligence."
          </h3>
          <div className="button-section">
            <div className="button play">
              <span>
                <i className="fas fa-play"></i>
              </span>
              Play
            </div>
            <div className="button more">
              <span>
                <i className="fas fa-info-circle"></i>
              </span>
              More info
            </div>
          </div>

        </div>

      </div>
    </>
  )}

export default HeroSection


