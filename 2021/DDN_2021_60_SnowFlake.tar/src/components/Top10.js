

//  This is the third of four components on our home page.
//  This is the first that actually presents any data.
//
//  Here we mean to mimic the famous NetFlix "Top 10 in the US Today"
//  or "Trending Now" type display.
//
//  More,
//
//  .  Our OLTP data is in DataStax Astra, a hosted Apache Cassandra
//     database server
//  .  this data, our OLAP data (tout N data) comes from SnowFlake.


import Card from "./Card"


const Top10 = ({ top10 }) => {
  return (
    <div>
    <>
    <h2 id="Top10">Trending in the World Today</h2>
    <table>
    <tbody>
      <tr>
      <td>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </td>
      <td>
        {top10 && (
          <div id="div_top10" className="movie-section">
            {top10.map((movie, index) => (
              <Card key={index} movie={movie} />
            ))}
          </div>
         )}
      </td>
      </tr>
    </tbody>
    </table>
    <hr height="24px;"></hr>
    </>
    </div>
  )
  }

export default Top10

