

//  This is "Card"
//
//  Card is effectively one movie listing, used in both "Section"
//  and "Top10".
//
//  When the end user highlights a given movie (emulating having
//  watching that film), we write this event to SnowFlake, and
//  re-query/re-display the Top10 list.

import {saveEvent, getTop10 } from "../utils/Api"


const Card = ({ movie, setTop10 }) => {

  const handleMouseEnter = async (e) => {
    if(setTop10) {

      //  Write an event to SnowFlake
      //
      await saveEvent({movie})

      //  Read back the Top10, Because it's changed.
      //
      const newTop10 = await getTop10()
      setTop10(newTop10)
    }
  }

  return (
    <div
      className="card"
      onMouseEnter={handleMouseEnter}
    >
      <>
        <video className="video" controls source src={movie.thumbnail} type="video/mp4" />
        <div className="info-box">
          <p>{movie.title}</p>
        </div>
      </>
    </div>
  )
}

export default Card




