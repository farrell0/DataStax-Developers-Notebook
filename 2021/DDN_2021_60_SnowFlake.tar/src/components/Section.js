

//  This is one of two files that give us the fourth and final section 
//  of data on our home page
//
//  This "Section" is this fourth piece. This/Section uses "Card" which
//  is a given single movie proper. Card is used here and in the Top10.

import { useEffect, useState } from "react"
import Card from "./Card"

const Section = ({ genre, setTop10 }) => {
  const [movies, setMovies] = useState(null)

  const fetchData = async () => {
    const response = await fetch("/.netlify/functions/getMovies", {
      method: "POST",
      body: JSON.stringify({ genre: genre }),
    })
    const responseBody = await response.json()
    setMovies(responseBody.data.movies_by_genre.values)
  }

  useEffect(() => {
    fetchData()
  }, [])

  return (
    <>
      <h2 id={genre}>{genre}</h2>
      {movies && (
        <div className="movie-section">
          {movies.map((movie, index) => (
            <Card key={index} movie={movie} setTop10={setTop10} />
          ))}
        </div>
      )}
    </>
  )
}

export default Section

