

//  This file presents the absolute smallest example of something
//  served thru the Netlify CLI
//
//  .  Starting your application hosting from the command line via
//     a,
//        netlify dev
//     you will received the endpoint where this application can be 
//     reached; both localhost, and a given IP
//
//   .  To run this service, enter this in the address bar to your
//      browser,  (substitute localhost with your actual IP address)
//         localhost:8888/.netlify/functions/zz01_HelloWorld
//
//      You should see the JSON string below with the 'jjj' cconstants.


exports.handler = async function () {

  return {
    statusCode: 200,
    body: JSON.stringify({jjj: 'jjj'})
  }

}


