

const fetch = require('node-fetch')

exports.handler = async function (event) {
 const movies = [
      {title: "Forrest Gump", cntr: 8, thumbnail: "https://i.imgur.com/V6WMXYx.mp4"},
      {title: "Pulp Fiction", cntr: 3, thumbnail: "https://i.imgur.com/8xf630M.mp4"},
      {title: "The Matrix"  , cntr: 4, thumbnail: "https://i.imgur.com/QzJe4nJ.mp4"}
    ]
  try {
    return {
      statusCode: 200,
      body: JSON.stringify(movies)
    }
  } catch (e) {
    console.log(e)
    return {
      statusCode: 500,
      body: JSON.stringify(e)
    }
  }
}


