

//  Get the "Top 10 in the US" type function similar to NetFlix
//  home page.
//
//  But .. .. simpler display, we get only four.
//  Data comes from SnowFlake.

const { executeSQL} = require('./utils/snowflakeUtils')

exports.handler = async function (event, context) {

  const msg = JSON.parse(event.body)
  const title = msg.movie.title
     //
  const stmt = 'update demo_db.public."top_10" set "cntr" = ( "cntr" + 1 ) WHERE "title" = \'' + title + '\';'

  try {
  
    const rows = await executeSQL(stmt)

    return {
      statusCode: 200,
      body: JSON.stringify(rows)
    }

  } catch (e) {
    console.log(e)
    return {
      statusCode: 500,
      body: JSON.stringify(e)
    }
  }

}
