

//  This utility file is largely to avoid repetitive code to connect
//  to SnowFlake as we SELECT, UPDATE ..

const snowflake = require('snowflake-sdk')

const connection = snowflake.createConnection(
    {
    account: "wnZZZZZZZZZZZZZZZZZZZcp",
    username: "EEEEEEEE",
    password: "YYYYYYYYYYYY",
    authenticator: "SNOWFLAKE"
    }
)

connection.connect(
function(err, conn) {
    if (err) {
        console.error('Unable to connect: ' + err.message);
        }
    else {
        console.log('Successfully connected to Snowflake.');
        }
    }
)

function executeSQL(sql) {
    return new Promise(resolve => {
      connection.execute({
        sqlText: sql,
        complete: function(err, stmt, rows) {
          if (err) {
            console.error('Failed to execute statement due to the following error: ' + err.message)
          } else {
            console.log('Number of rows produced: ' + rows.length)
            resolve(rows);
          }
        }
      });
    })
  }

  module.exports = {
      executeSQL
  };


