

//  Get the "Top 10 in the US" type function similar to NetFlix
//  home page.
//
//  But .. .. simpler display, we get only four.
//  Data comes from SnowFlake.

const { executeSQL} = require('./utils/snowflakeUtils')

exports.handler = async function () {
  
  try {
  
    const rows = await executeSQL('select * from demo_db.public."top_10" order by "cntr" desc limit 4;');

    return {
      statusCode: 200,
      body: JSON.stringify(rows)
    }

  } catch (e) {
    console.log(e)
    return {
      statusCode: 500,
      body: JSON.stringify(e)
    }
  }

}
