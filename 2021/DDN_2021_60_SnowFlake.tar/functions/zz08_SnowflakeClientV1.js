

//  Test program; getting connectivity to SnowFlake
//
//  Not set up to be a Netlify function, we can run this from
//  the command line

const snowflake = require('snowflake-sdk')

const connection = snowflake.createConnection(
  {
  account: "wn96XXXXXXXXXXXXXl1.gcp",
  username: "faXXXXl0",
  password: "XXXXXXXXXXXX",
  authenticator: "SNOWFLAKE"
  }
)

connection.connect( 
  function(err, conn) {
      if (err) {
          console.error('Unable to connect: ' + err.message);
          } 
      else {
          console.log('Successfully connected to Snowflake.');
          }
      }
  );


  var statement = connection.execute({
    sqlText: 'select * from demo_db.public.top_10;',
  });
  
  var stream = statement.streamRows();
  
  stream.on('error', function(err) {
    console.error('Unable to consume all rows');
  });
  
  //  this is their looping construct over all rows
  //
  stream.on('data', function(row) {
    console.log(row)
  });
  
  stream.on('end', function() {
    console.log('All rows consumed');
  });



