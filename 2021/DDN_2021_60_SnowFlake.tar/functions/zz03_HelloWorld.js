

//  A little more over example 01
//
//  Need to use Postman or similar to pass a header;
//     Body, Raw, { "name": "Jason" }
//     and content-type app/json
//
//     localhost:8888/.netlify/functions/zz02_HelloWorld


exports.handler = async function (event, context) {

  const { name } = JSON.parse(event.body)

  //  'null' here would be the error
  //
  return (null, {
    statusCode: 200,
    body: JSON.stringify({msg: 'Hello ' + name})
  })

}


