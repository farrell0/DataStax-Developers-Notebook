

   DataStax Astra, SnowFlake Cloud Data Platform, demonstration program
   =====================================================

   .  Essentially run a simple NetFlix looking Web app written in Node.js/
      REACT, with OLTP services in Apache Cassandra, hosted by DataStax,
      and OLAP hosted by SnowFlake Cloud Data Plaform.

   .  DataStax Astra is DataStax's managed Apache Cassandra offering.
      Sign up for free at,
         astra.datastax.com

      Astra includes REST, Document-API, GraphQL and more thru the DataStax       
      StarGate subsystem; also free, also hosted.

   .  SnowFlake Cloud Data Platform is also available for free at,
         SnowFlake.com

      This demonstration program uses the SnowFlake Node.JS client side
      driver detailed here,
         https://docs.snowflake.com/en/user-guide/nodejs-driver-use.html

   .  Original NetFlix clone program based on work by Ania Kubow
      Source code,
         https://github.com/kubowania/netflix-clone-graphql-datastax
      Getting started video,
         https://youtu.be/g8COh40v2jU

   .  DataStax Astra offers free hosted GraphQL thru it's StarGate subsystem.
      To most easily make use of that, we also use the serverless functions
      of Netlify's CLI, detailed here,
         https://docs.netlify.com/cli/get-started/

   .  Looking to learn this program ?
   
      Start in App.js



         