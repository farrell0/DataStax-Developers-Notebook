#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to copy our previous snapshot of 'cluster1' into a PVC for 'cluster2' ..."
echo ""
echo "   If you see this error (or similar),"
echo "      Warning: kubectl apply should be used on resource created by either"
echo "         kubectl create --save-config or kubectl apply"
echo "      The PersistentVolumeClaim "server-data-cluster2-system2-default-sts-0" is invalid:"
echo "         spec: Forbidden: is immutable after creation except resources.requests for bound claims"
echo ""
echo "   Then you had previously booted 'cluster2', and you must delete it's associated PVC first."
echo ""
echo "   Or you might see,"
echo "      persistentvolumeclaim/server-data-cluster2-system2-default-sts-0 unchanged"
echo ""
echo "   Which means you previously created/restored the disk for 'cluster2'."
echo ""
echo ""
echo "   Generally though, you want to run this command,"
echo "         kubectl -n cass-operator delete pvc server-data-cluster2-system2-default-sts-0"
echo ""
echo "         (We don't have an existing stand alone program for the above.)"
echo ""
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
sleep 10


kubectl -n cass-operator apply -f S3_ReplaceVolumeWithSnapshot.yaml
   

echo ""
echo ""
echo "Next steps:"
echo ""
echo "   Boot 'cluster2'. (Perhaps use '40* D8*'."
echo ""
echo "   'cluster2' should have the same data as 'cluster1', but in a newly named cluster."
echo ""
echo ""









