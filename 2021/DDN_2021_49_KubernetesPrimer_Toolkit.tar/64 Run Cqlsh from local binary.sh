#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to create a K8s tunnel, and run a local CQLSH ..."
echo "   (If you pass a command line argument, that argument is passed as a 'cqlsh -f \$1' )"
echo ""
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
sleep 10


##############################################################


#  Data looks similar to,
#
#    cass-operator   cass-operator-55ddb95c99-f7ws7                              1/1     Running   0          48m
#    cass-operator   cluster2-system2-default-sts-0                              2/2     Running   0          36m
#
#  Use kubectl to get the 2nd line, 2nd word prefix

l_UserName=`kubectl get pods --namespace=${MY_NS_CASS} --no-headers | awk '{print $1}' | grep -v ${MY_NS_CASS} | head -1 | cut -f1,1 -d'-'`-superuser
   #
CASS_USER=$(kubectl -n ${MY_NS_CASS} get secret ${l_UserName} -o json | grep -A2 '"data": {' | grep '"username":' | awk '{print$2}' | sed 's/"//' | base64 --decode 2> /dev/null)
CASS_PASS=$(kubectl -n ${MY_NS_CASS} get secret ${l_UserName} -o json | grep -A2 '"data": {' | grep '"password":' | awk '{print$2}' | sed 's/"//' | base64 --decode 2> /dev/null)


#  shuf(C) generates a random number-
#
#  Why we're doing this;  Any given node may be down given our extreme
#  testing.
#

l_num_nodes=`kubectl get pods -n ${MY_NS_CASS} | egrep -v "NAME|${MY_NS_CASS}-" | wc -l`
l_which_node=`shuf -i 1-${l_num_nodes} -n 1`
   #
l_node=`kubectl get pods -n ${MY_NS_CASS} | egrep -v "NAME|${MY_NS_CASS}-" | sed ${l_which_node}'!d' | awk '{print $1}'`


kubectl port-forward ${l_node} 9042:9042 -n ${MY_NS_CASS} &
l_my_pid=${!}
   #
sleep 5


[ ${#} -gt 0 ] && {
   cqlsh -u ${CASS_USER} -p ${CASS_PASS} -f $1
} || {
   cqlsh -u ${CASS_USER} -p ${CASS_PASS} 
}

kill -15 ${l_my_pid}


echo ""
echo ""





