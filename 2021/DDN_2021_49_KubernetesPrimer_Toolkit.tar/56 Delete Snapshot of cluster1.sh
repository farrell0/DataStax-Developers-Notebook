#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to delete our previous snapshot of 'cluster1' ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
sleep 10


kubectl -n cass-operator delete volumesnapshot my-snapshot

   
echo ""
echo ""





