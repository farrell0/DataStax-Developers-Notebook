#!/bin/bash


#  From,
#     https://kubernetes.io/docs/tasks/run-application/force-delete-stateful-set-pod/


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to kill a given Cassandra node ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
echo ""
echo "Ps: if you pass any command line argument, the node is flushed before it is killed."
echo ""
echo ""
sleep 10


l_cass_pods=$(kubectl get pods --namespace=${MY_NS_CASS} --no-headers | awk '{print $1}' | grep -v ${MY_NS_CASS})
l_cntr=0

for l_node in ${l_cass_pods}
   do
   l_cntr=$((l_cntr+1))
   echo "  "${l_cntr}":  "${l_node}
   done
      
echo ""
echo ""
echo -n "Enter the node number to kill: "
   #
read l_numb
   #
[ -z ${l_numb} ] && {
   l_numb=0
}


##############################################################


l_cntr=0

for l_node in ${l_cass_pods}
   do

   l_cntr=$((l_cntr+1))
      #
   [ ${l_cntr} -eq ${l_numb} ] && {

      [ ${#} -gt 0 ] && {
         kubectl --namespace=${MY_NS_CASS} exec -it ${l_node} "nodetool flush"
      } || {
         :
      }
      kubectl --namespace=${MY_NS_CASS} delete pods ${l_node} --grace-period=0 --force
   } || {
      :
   }

   done

echo ""
echo ""







