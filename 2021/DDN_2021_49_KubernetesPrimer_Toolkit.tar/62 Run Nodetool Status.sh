#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo ""
echo "Use 'kubectl' to run nodetool status. With our testing, any given"
echo "C* node may be down. So, run this from a random C* node."
echo ""
echo "(So, if this program fails, run it again.)"
echo ""
echo ""

#  shuf(C) generates a random number-
#
#  Why we're doing this;  Any given node may be down.

l_num_nodes=`kubectl get pods -n ${MY_NS_CASS} | egrep -v "NAME|${MY_NS_CASS}-" | wc -l`
l_which_node=`shuf -i 1-${l_num_nodes} -n 1`
   #
l_node=`kubectl get pods -n ${MY_NS_CASS} | egrep -v "NAME|${MY_NS_CASS}-" | sed ${l_which_node}'!d' | awk '{print $1}'`

echo "Running from node: "${l_node}
kubectl -n ${MY_NS_CASS} exec -it -c cassandra ${l_node} -- nodetool status

echo ""
echo ""








