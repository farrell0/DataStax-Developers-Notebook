#!/bin/bash


#  GCP machines types,
#
#     https://cloud.google.com/compute/docs/machine-types#n2_machine_types
#
#   gcloud compute zones list


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'gcloud' to create K8s cluster ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
sleep 10


#  This was my version of this command before I started testing/using
#  snapshots.
#
# gcloud beta container --project ${GKE_PROJECT}   \
#    clusters create ${MY_CLUSTER}    \
#    --zone ${GKE_ZONE}    \
#    --no-enable-basic-auth    \
#    --cluster-version "1.16.15-gke.4300"    \
#    --machine-type "n2-standard-8"    \
#    --image-type "COS"    \
#    --disk-type "pd-standard"    \
#    --disk-size "1000"    \
#    --metadata disable-legacy-endpoints=true    \
#    --scopes "https://www.googleapis.com/auth/devstorage.read_only","https://www.googleapis.com/auth/logging.write","https://www.googleapis.com/auth/monitoring","https://www.googleapis.com/auth/servicecontrol","https://www.googleapis.com/auth/service.management.readonly","https://www.googleapis.com/auth/trace.append"    \
#    --num-nodes "4"    \
#    --enable-stackdriver-kubernetes    \
#    --enable-ip-alias    \
#    --default-max-pods-per-node "110"    \
#    --no-enable-master-authorized-networks    


#  These lines below add support for snapshots,
#
#     --cluster-version "1.17.14-gke.400" 
#     --addons=GcePersistentDiskCsiDriver 
#

#  For Jaimon test, changed this
#       --machine-type "n2-standard-8"            #  32 GB RAM
#  to 
#       --machine-type "n2-standard-16"           #  64 GB RAM
#       --machine-type "n2-standard-32"           #  128 GB RAM, which is past my quota


gcloud beta container --project ${GKE_PROJECT}   \
   clusters create ${MY_CLUSTER}    \
   --zone ${GKE_ZONE}    \
   --no-enable-basic-auth    \
   --cluster-version "1.17.14-gke.400"    \
   --addons=GcePersistentDiskCsiDriver \
   --machine-type "n2-standard-16"    \
   --image-type "COS"    \
   --disk-type "pd-standard"    \
   --disk-size "1000"    \
   --metadata disable-legacy-endpoints=true    \
   --scopes "https://www.googleapis.com/auth/devstorage.read_only","https://www.googleapis.com/auth/logging.write","https://www.googleapis.com/auth/monitoring","https://www.googleapis.com/auth/servicecontrol","https://www.googleapis.com/auth/service.management.readonly","https://www.googleapis.com/auth/trace.append"    \
   --num-nodes "4"    \
   --enable-stackdriver-kubernetes    \
   --enable-ip-alias    \
   --default-max-pods-per-node "110"    \
   --no-enable-master-authorized-networks    



#  Moving to a 'rapid' channel release, K8s 1.18 and higher
#
#  From,
#     https://cloud.google.com/kubernetes-engine/docs/how-to/upgrading-a-cluster
#
#  Supported rapid channel versions,
#     https://cloud.google.com/kubernetes-engine/docs/release-notes-rapid
#
# echo ""
# gcloud container clusters update farrell-cluster --release-channel rapid
# gcloud container clusters upgrade -q farrell-cluster --master --cluster-version "1.18.12-gke.1201"
# gcloud container clusters upgrade -q farrell-cluster

echo ""
echo ""


#  Which versions are avail ?
#
#     gcloud container get-server-config --format "yaml(channels)" --zone ${GKE_ZONE}
#        Fetching server config for us-central1-a
#        channels:
#        - channel: RAPID
#          defaultVersion: 1.18.12-gke.1200
#          validVersions:
#          - 1.18.12-gke.1201
#          - 1.18.12-gke.1200
#        - channel: REGULAR
#          defaultVersion: 1.17.13-gke.2600
#          validVersions:
#          - 1.17.14-gke.400
#          - 1.17.13-gke.2600
#        - channel: STABLE
#          defaultVersion: 1.16.15-gke.4901
#          validVersions:
#          - 1.16.15-gke.5500
#          - 1.16.15-gke.4901
#          - 1.16.15-gke.4301
#          - 1.16.15-gke.4300
#          - 1.15.12-gke.6002
#          - 1.15.12-gke.6001
#          - 1.15.12-gke.20



