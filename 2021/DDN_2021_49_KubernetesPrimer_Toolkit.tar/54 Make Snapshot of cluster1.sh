#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to snapshot the 1 node 'cluster1' C* cluster ..."
echo ""
echo "   Generally at this point:"
echo "      .  If you made a previous snapshot, delete it first. Use file 56*."
echo ""
echo "      .  You put data in 'cluster1'. (Use the T1 CQL script, for example.)"
echo "      .  You updated 'system.local'. (The T3 CQL does that for you.)"
echo "      .  You 'nodetool flush'ed 'cluster1'. (Run file 68*.)"
echo "      .  Required; you shut 'cluster1' cluster down. (40* D2*)"
echo "         If you don't shut the cluster down first, then the copies you make will be BOUND, not AVAILABLE."
echo ""
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
sleep 10


kubectl -n cass-operator apply -f S2_CreateSnapshot.yaml


##############################################################


#
#  This snapshot takes a while to be (ready). This loop will exit
#  when the snapshot is ready.
#
l_cntr=0
   #
while :
   do
   #  This sed(C) removes multiple space characters.
   #
   l_if_ready=`kubectl -n cass-operator describe volumesnapshot | sed 's/[ ]\+/ /g' | grep "Ready To Use: true" | wc -l`
      #
   [ ${l_if_ready} -gt 0 ] && {
      break 
   } || {
      l_cntr=$((l_cntr+1))
      echo "   Waiting .. ("${l_cntr}")"
         #
      sleep 5
   }
   done

echo "   Waiting .. (complete)"


echo ""
echo ""
echo "Next steps:"
echo "  Run program 55*, which calls to restore this snapshot into a PVC that will be used by 'cluster2'."
echo ""
echo "  (If needed; program 56* deletes said snapshot made above.)"
echo ""
echo ""








