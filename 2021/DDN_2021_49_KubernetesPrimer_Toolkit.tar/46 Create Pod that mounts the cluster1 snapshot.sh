#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to make a pod we will mount/view the 'cluster1' snapshot from ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo "**  If this pod or namespace existed previously, they are dropped and recreated."
echo "**  You should snapshot your 'cluster1' single pod cluster before proceeding."
echo ""
echo ""
echo "Edit the E2* YAML file if you have specific changes you want made."
echo "  (Currently, /opt2, inside the pod, will be writable.)"
echo ""
echo ""
sleep 10


##############################################################


#
#  Are there any existing pods. If Yes, kill them.
#
l_num_pods=`kubectl get pods -A | grep ${MY_NS_USER} | grep generic-pod | wc -l`
   #
[ ${l_num_pods} -eq 0 ] || {
   kubectl -n ${MY_NS_USER}  delete pods generic-pod --grace-period=0
}
#
#  Does the target namespace already exist. If Yes, delete it.
#
l_num_ns=`kubectl get namespaces | grep ${MY_NS_USER} | wc -l`
   #
[ ${l_num_ns} -eq 0 ] || {
   kubectl delete namespaces ${MY_NS_USER}
}


##############################################################


kubectl create namespace ${MY_NS_USER}

echo ""

kubectl -n ${MY_NS_USER} create -f E2_pod_into_snapshot.yaml


##############################################################


#
#  These pods take a bit of time to actually come up. This wait
#  loop will exit when the pod is ready.
#
l_cntr=0
   #
while :
   do
   l_if_ready=`kubectl get pods -n ${MY_NS_USER} --no-headers | grep "^snapshot-data-pod" | grep Running | wc -l`
      #
   [ ${l_if_ready} -gt 0 ] && {
      break 
   } || {
      l_cntr=$((l_cntr+1))
      echo "   Initializing .. ("${l_cntr}")"
         #
      sleep 5
   }
   done

echo "   Initializing .. (complete)"
echo ""
echo ""
echo "Next steps:"
echo "   Login: Run file 69*"
echo ""
echo ""








