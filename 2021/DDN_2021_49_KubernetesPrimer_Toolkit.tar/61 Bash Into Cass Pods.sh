#!/bin/bash


. "./20 Defaults.sh"


##############################################################


echo ""
echo "Calling 'kubectl' to Bash into Cassandra nodes ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo ""
echo ""
echo "Ps: if you pass a logical pod number, we will Bash into just that pod."
sleep 10


l_cntr=0
l_arg1=${1}


##############################################################


#  Data looks like,
#     
#     kubectl --namespace=${MY_NAMESPACE} get pods
#        NAME                             READY   STATUS    RESTARTS   AGE
#        cass-operator-55ddb95c99-d4w9c   1/1     Running   0          95m
#        cluster1-dc1-default-sts-0       2/2     Running   0          40m
#        cluster1-dc1-default-sts-1       2/2     Running   0          40m
#        cluster1-dc1-default-sts-2       2/2     Running   0          40m


for l_node in `kubectl --namespace=${MY_NS_CASS} get pods | egrep -v "NAME|${MY_NS_CASS}-" | awk '{print $1}'`
   do

   l_cntr=$((l_cntr+1))
  
   [ ${#} -gt 0 ] && {

      #  Got a command line argument. If this argument is an integer, then
      #  ssh into this node only-

      [[ ${l_arg1} == ?(-)+([0-9]) ]] && {

         [ ${l_arg1} -eq ${l_cntr} ] && {
            echo ""
            echo ""
            echo "Entering node: "${l_node}
            echo "==========================================="
            kubectl --namespace=${MY_NS_CASS} exec -it ${l_node} -- bash
            echo ""
         } || {
            :
         }

      } || {
         echo ""
         echo ""
         echo "ERROR:  You passed a first command line argument that is not an integer."
         echo ""
         echo ""
         exit 1
      }

   } || { 

      echo ""
      echo ""
      echo "Entering node: "${l_node}
      echo "==========================================="
      echo ""
      kubectl --namespace=${MY_NS_CASS} exec -it ${l_node} -- bash
      echo ""

   }

   done






