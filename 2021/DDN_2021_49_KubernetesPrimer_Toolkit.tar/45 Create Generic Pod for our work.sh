#!/bin/bash


. "./20 Defaults.sh"


##############################################################


l_UserName=`kubectl get pods --namespace=${MY_NS_CASS} --no-headers | awk '{print $1}' | grep -v ${MY_NS_CASS} | head -1 | cut -f1,1 -d'-'`-superuser
   #
CASS_USER=$(kubectl -n ${MY_NS_CASS} get secret ${l_UserName} -o json | grep -A2 '"data": {' | grep '"username":' | awk '{print$2}' | sed 's/"//' | base64 --decode 2> /dev/null)
CASS_PASS=$(kubectl -n ${MY_NS_CASS} get secret ${l_UserName} -o json | grep -A2 '"data": {' | grep '"password":' | awk '{print$2}' | sed 's/"//' | base64 --decode 2> /dev/null)

#
#  Get a list of internal IPs, pods that run a C* node
#
l_PodNames=`kubectl describe pods -n ${MY_NS_CASS} | grep "^Name:" | awk '{print $2}' | grep -v "^cass-operator-"`
   #
l_ip_list1=`kubectl -n ${MY_NS_CASS} describe pods ${l_PodNames} | grep "^IP:" | awk '{print $2}'`
l_ip_list2=`echo ${l_ip_list1} | sed 's/ /,/g'`


echo "CASS_USER=${CASS_USER}"            >  21_DefaultsOnGenericPod.sh
echo "CASS_PASS=${CASS_PASS}"            >> 21_DefaultsOnGenericPod.sh
echo "IP_LIST=${l_ip_list2}"             >> 21_DefaultsOnGenericPod.sh
   #
chmod 777                                   21_DefaultsOnGenericPod.sh


##############################################################


echo ""
echo "Calling 'kubectl' to make a generic pod/container that we can run C* clients from ..."
echo ""
echo "**  You have 10 seconds to cancel before proceeding."
echo "**  If this pod or namespace existed previously, they are dropped and recreated."
echo "**  Your C* cluster should be up and running before proceeding."
echo ""
echo ""
echo "Edit the E1* YAML file if you have specific changes you want made."
echo "  (Currently, /opt2, inside the pod, will be writable.)"
echo ""
echo ""
sleep 10


##############################################################


#
#  Are there any existing pods. If Yes, kill them.
#
l_num_pods=`kubectl get pods -A | grep ${MY_NS_USER} | grep generic-pod | wc -l`
   #
[ ${l_num_pods} -eq 0 ] || {
   kubectl -n ${MY_NS_USER}  delete pods generic-pod --grace-period=0
}
#
#  Does the target namespace already exist. If Yes, delete it.
#
l_num_ns=`kubectl get namespaces | grep ${MY_NS_USER} | wc -l`
   #
[ ${l_num_ns} -eq 0 ] || {
   kubectl delete namespaces ${MY_NS_USER}
}


##############################################################


kubectl create namespace ${MY_NS_USER}

echo ""

kubectl -n ${MY_NS_USER} create -f E1_generic_pod.yaml


##############################################################


#
#  These pods take a bit of time to actually come up. This wait
#  loop will exit when the pod is ready.
#
l_cntr=0
   #
while :
   do
   l_if_ready=`kubectl get pods -n ${MY_NS_USER} --no-headers | grep "^generic-pod" | grep Running | wc -l`
      #
   [ ${l_if_ready} -gt 0 ] && {
      break 
   } || {
      l_cntr=$((l_cntr+1))
      echo "   Initializing .. ("${l_cntr}")"
         #
      sleep 5
   }
   done

echo "   Initializing .. (complete)"
echo "   File copies .."
   #
kubectl -n ${MY_NS_USER}  cp 84_RunStressOnGenPod.sh       generic-pod:/opt2/84_RunStressOnGenPod.sh   
kubectl -n ${MY_NS_USER}  cp 85_RunNbOnGenPod.sh           generic-pod:/opt2/85_RunNbOnGenPod.sh   
kubectl -n ${MY_NS_USER}  cp N2_NoSqlBench_Job.yaml        generic-pod:/opt2/N2_NoSqlBench_Job.yaml
kubectl -n ${MY_NS_USER}  cp 21_DefaultsOnGenericPod.sh    generic-pod:/opt2/21_DefaultsOnGenericPod.sh


echo ""
echo ""
echo "Next steps:"
echo "   Login: Run file 67*"
echo ""
echo ""








