#!/bin/bash


#
#  This file is sourced from most programs in this folder; 
#  variables used throughout
#


alias kc=kubectl

GKE_PROJECT=gke-launcher-dev
GKE_ZONE=us-central1-a
   #
MY_CLUSTER=farrell-cluster

MY_NS_CASS=cass-operator
MY_NS_USER=my-namespace

#
#  Which mount point, Eg., /dev/sdb
#  is /var/lib/cassandra (the data file directories) mounted on
#  in each C* pod.
#
MY_WHICH_FS=/dev/sdb


