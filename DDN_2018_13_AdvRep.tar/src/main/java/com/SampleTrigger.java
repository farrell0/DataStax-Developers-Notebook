

package com;


import org.apache.cassandra.config.Schema;
import org.apache.cassandra.config.CFMetaData;
import org.apache.cassandra.config.ColumnDefinition;
   //
import org.apache.cassandra.db.Mutation;
import org.apache.cassandra.db.Clustering;
   //
import org.apache.cassandra.db.partitions.Partition;
import org.apache.cassandra.db.partitions.PartitionUpdate;
   //
import org.apache.cassandra.db.rows.UnfilteredRowIterator;
import org.apache.cassandra.db.rows.Unfiltered;
import org.apache.cassandra.db.rows.Cell;
   //
import org.apache.cassandra.triggers.ITrigger;
   //
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
   //
import java.lang.StringBuffer;
   //
import org.apache.cassandra.utils.UUIDGen;


public class SampleTrigger implements ITrigger {


   public Collection<Mutation> augment(Partition i_partition) {
 
       String l_dest_ks   = "ks_13b"  ;
       String l_dest_tb   = "my_audit";
          //
       String l_srce_ks   = i_partition.metadata().ksName;
       String l_srce_tb   = i_partition.metadata().cfName;
          //
       String l_srce_pk   = i_partition.metadata().getKeyValidator().
             getString(i_partition.partitionKey().getKey());

       // 
       //  Deletions will have an entry similar to,
       //
       //     deletedAt=1511809909210445, localDeletion=1511809909
       //     deletedAt=1511809919795488, localDeletion=1511809919
       //     deletedAt=1511809962879741, localDeletion=1511809962
       //
       //  Inserts/Updates will have an entry similar to,
       //
       //     deletedAt=-9223372036854775808, localDeletion=2147483647
       //     deletedAt=-9223372036854775808, localDeletion=2147483647
       //     deletedAt=-9223372036854775808, localDeletion=2147483647
       //
       String l_srce_type = i_partition.partitionLevelDeletion().toString();


       //
       //  Needs work; robust enough for our simple example
       //
       UnfilteredRowIterator l_rows = i_partition.unfilteredIterator();
          //
       StringBuffer l_srce_data = new StringBuffer(1024);
       //
       //  Loop through all rows
       //
       while (l_rows.hasNext()) {
          Unfiltered l_row = l_rows.next();
          Clustering l_rowClust = (Clustering) l_row.clustering();  
          Iterator<Cell> l_cells = i_partition.getRow(
                l_rowClust).cells().iterator();
          Iterator<ColumnDefinition> l_cols = i_partition.getRow(
                l_rowClust).columns().iterator();
          //
          //  Loop through all cols
          //
          while(l_cells.hasNext())
             {
             Cell l_cell = l_cells.next();
             ColumnDefinition l_col = l_cols.next();
                //
             l_srce_data.append(l_col + ":");
             l_srce_data.append(new String(l_cell.value().array()) + ",");
             }
          }


       //
       //  Setup our new/copy row
       //
       CFMetaData l_metadata = Schema.instance.getCFMetaData(
             l_dest_ks, l_dest_tb);
 
       //
       //  Add a timestamp primary key
       //
       PartitionUpdate.SimpleBuilder l_audit = PartitionUpdate.
             simpleBuilder(l_metadata, UUIDGen.getTimeUUID());
 
       //
       //  Add remaining columns
       //
       l_audit.row()
          .add("source_ks"   , l_srce_ks             )
          .add("source_tb"   , l_srce_tb             )
          .add("source_pk"   , l_srce_pk             ) 
          .add("source_data" , l_srce_data.toString()) 
          .add("source_type" , l_srce_type           );
 
       return Collections.singletonList(l_audit.buildAsMutation());
   }


}



