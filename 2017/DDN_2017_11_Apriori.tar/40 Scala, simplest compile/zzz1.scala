


//
//  Compiled with a,
//     scalac zzz1.scala
//
//  Run with a,
//     scala zzz1
//
 

object zzz1 {

   def main(args: Array[String]): Unit = {

      println("Goodbye Hollywood !")

   }

}
