

#
#  Run via,
# 
#      dse spark-submit /tmp/farrell0/file_name.py
#
#  Didn't run exhaustive tests. Seemed I needed an
#  absolute pathname with no spaces.
#


from pyspark.sql import Row, SQLContext
from pyspark import SparkContext, SparkConf


# simple python code to see a spark-submit


conf = SparkConf().setAppName("Simple Python script via spark submit")

sc = SparkContext(conf=conf)
sqlContext = SQLContext(sc)


def getData():
   case = sqlContext.read.format("org.apache.spark.sql.cassandra").options(table="association_rules", keyspace="ks_11").load()
      #
   case.registerTempTable("my_temp")
   caseForML = sqlContext.sql("select * from my_temp")
   caseForML.show()
      #
   sc.stop()


if __name__ == "__main__":
   getData()




