

#
#  This program output association rules from an internal
#  hard coded grocery data set.
#
#  Association rules as in; persons who buy pasta buy wine
#  60% of the time, or whatever.
#
#  This point of this program is that it delivers the 
#  Apriori algorithm entirely by hand, so that you may
#  see in detail what an Apriori routine does.
#
#  This program borrows heavily from Ch 11 in the Manning
#  book, Machine Learning in Action, by Peter Harrington.
#

#
#  frequent items sets, items bought together
#  association rules, support and confidence for the above
#
#  Tx num   Items
#  ------   ----------------------------------------
#     0     soy milk, lettuce
#     1     lettuce, diapers, wine, chard
#     2     soy milk, diapers, wine, OJ
#     3     lettuce, soy milk, diapers, wine
#     4     lettuce, soy milk, diapers, OJ
#
#  support, percentage of dataset that contains a given
#  itemset. Above, soy and diapers is 3/5.
#
#  confidence,
#      support (A,B) / support (A)
#
#  so, support (diapers, wine: 3/5) / support (diapers: 4/5)
#
#     .. (3/5) / (4/5)  = .6 / .8 = 75%
#
#  Take each item above and produce item sets,
#
#  soy -> lettuce              (tx 0)
#  soy -> diapers              (tx 2)
#  soy -> diapers, wine        (tx 2)
#  soy -> diapers, wine, OJ    (tx 2)
#     ..
#
#  A dataset with N items can generate 2 ^ N - 1
#    possible itemsets  (power of)
#
#  A store with 100 items can generate 1.26 * 10 ^ 30
#  item sets.
#
#
#  Apriori, Latin 'from before'. A means to optimize
#  the above. Eg, if A/B is in/frequent, then A/B/C,
#  A/B/D, and A/B/C/D are also in/frequent.
#
#  The impact above is, if 'support' of A/B is not
#  to our liking, we don't have to calc A/B/C ..
#

from numpy import *




###########################################################
###########################################################


#
#  From our list of orders, create a list of unique
#  single items.
#
#  Why ?
#
#  From this list we can create all subsequent pairs,
#  triplets, and higher lists of items.
#
def create_itemSet(i_orders):

   l_itemSet = []

   for l_order in i_orders:
      for item in l_order:
         if not [item] in l_itemSet:
            l_itemSet.append([item])

   l_itemSet.sort()
     
   return map(frozenset, l_itemSet)


#
#  Input:
#     [ "soy milk" , "lettuce"                        ],
#     [ "lettuce"  , "diapers"  , "wine"    , "chard" ],
#     [ "soy milk" , "diapers"  , "wine"    , "OJ"    ],
#     [ "lettuce"  , "soy milk" , "diapers" , "wine"  ],
#     [ "lettuce"  , "soy milk" , "diapers" , "OJ"    ]
#
#  Output:
#     [
#     frozenset(['OJ']),
#     frozenset(['chard']),
#     frozenset(['diapers']),
#     frozenset(['lettuce']),
#     frozenset(['soy milk']),
#     frozenset(['wine'])
#     ]
#




###########################################################
###########################################################


#
#  sets and frozenset, See,
#     https://docs.python.org/2.4/lib/types-set.html
#
#  sets,   unordered collection of immutable values,
#            the set itself is mutable, not hashable
#     m = set()
#     m.add('lll')
#
#  frozenset,   the set itself is immutable, is hashable
#
#  fset = frozenset(m)
#
#
#  map(), See,
#     http://www.bogotobogo.com/python/python_fncs_map_filter_reduce.php
#
#  items = [1, 2, 3, 4, 5]
#  squared = []
#  for x in items:
#     squared.append(x ** 2)
#
#  [1, 4, 9, 16, 25]
#
#  Using map(),
#
#     items = [1, 2, 3, 4, 5]
#
#     def sqr(x): return x ** 2
#
#     list(map(sqr, items))
#
#     [1, 4, 9, 16, 25]
#


def generate_itemPairs(i_itemList, i_offset): 

   #
   #  This function takes an item list and generates all 
   #  next layer possible pairs items. Eg., if passed the
   #  set of item singles, generate item pairs.
   #
   #  Why only generate the next tier of pairs ?
   #
   #  Because each tier is expected to be evaluated and
   #  possibly pruned. Eg., if no one ever buys 'prunes',
   #  then the liklihood someone buys 'prunes' and 
   #  'chocolate' is also low.
   #
   r_itemList = []

   l_itemListLength = len(i_itemList)

   for i in range(l_itemListLength):
      for j in range(i + 1, l_itemListLength): 
            #
         L1 = list(i_itemList[i])[ : i_offset - 2]
         L2 = list(i_itemList[j])[ : i_offset - 2]
            #
         L1.sort() 
         L2.sort()
         #
         #  If the first elements (the keys) are equal
         #  then
         #
         if L1 == L2:
            # 
            #  Set union, which is the vertical bar symbol
            #
            #  Why ?
            #
            #  0  1  2  would output,
            #    0,1  0,2  1,2 
            #    which are all unique
            #
            #  When you hit the third level, you would need 
            #  a third loop to remove redundancy. Consider,
            #
            #    0,1  0,2  1,2
            #
            #    which gens,
            # 
            #       0,1,2  0,1,2  1,2  ..
            #
            #  This next line removes those dups
            #
            r_itemList.append(i_itemList[i] | i_itemList[j])

   return r_itemList


#
#  Input, pass 1:
#     [
#     frozenset(['chard']),
#     frozenset(['wine']),
#     frozenset(['diapers']),
#     frozenset(['soy milk']),
#     frozenset(['lettuce']),
#     frozenset(['OJ'])
#     ]
#     2
#
#  Output:
#     [
#     frozenset(['chard', 'wine']),
#     frozenset(['chard', 'diapers']),
#     frozenset(['soy milk', 'chard']),
#     frozenset(['lettuce', 'chard']),
#     frozenset(['chard', 'OJ']),
#     frozenset(['diapers', 'wine']),
#     frozenset(['soy milk', 'wine']),
#     frozenset(['lettuce', 'wine']),
#     frozenset(['OJ', 'wine']),
#     frozenset(['soy milk', 'diapers']),
#     frozenset(['lettuce', 'diapers']),
#     frozenset(['diapers', 'OJ']),
#     frozenset(['lettuce', 'soy milk']),
#     frozenset(['soy milk', 'OJ']),
#     frozenset(['lettuce', 'OJ'])
#     ]
#

#
#  Input, pass 2:
#     [
#     frozenset(['soy milk', 'diapers']),
#     frozenset(['lettuce', 'wine']),
#     frozenset(['lettuce', 'OJ']),
#     frozenset(['OJ', 'wine']),
#     frozenset(['soy milk', 'OJ']),
#     frozenset(['lettuce', 'soy milk']),
#     frozenset(['lettuce', 'chard']),
#     frozenset(['diapers', 'wine']), 
#     frozenset(['chard', 'diapers']),
#     frozenset(['diapers', 'OJ']),
#     frozenset(['soy milk', 'wine']),
#     frozenset(['lettuce', 'diapers']),
#     frozenset(['chard', 'wine'])
#     ]
#     3
#
#  Output,
#     [
#     frozenset(['soy milk', 'diapers', 'OJ']),
#     frozenset(['soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'OJ', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'wine']),
#     frozenset(['lettuce', 'chard', 'wine']),
#     frozenset(['lettuce', 'diapers', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'OJ']),
#     frozenset(['lettuce', 'OJ', 'chard']),
#     frozenset(['lettuce', 'OJ', 'diapers']),
#     frozenset(['soy milk', 'OJ', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'chard']),
#     frozenset(['lettuce', 'soy milk', 'diapers']),
#     frozenset(['lettuce', 'chard', 'diapers']),
#     frozenset(['OJ', 'diapers', 'wine']),
#     frozenset(['wine', 'chard', 'diapers'])
#     ]
#

#
#  Input, pass 3:
#     [
#     frozenset(['lettuce', 'chard', 'wine']),
#     frozenset(['wine', 'chard', 'diapers']),
#     frozenset(['soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'diapers', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'wine']),
#     frozenset(['lettuce', 'OJ', 'diapers']),
#     frozenset(['OJ', 'diapers', 'wine']),
#     frozenset(['soy milk', 'OJ', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'OJ']),
#     frozenset(['lettuce', 'chard', 'diapers']),
#     frozenset(['soy milk', 'diapers', 'OJ']),
#     frozenset(['lettuce', 'soy milk', 'diapers'])
#     ]
#     4
#
#  Output:
#     [
#     frozenset(['lettuce', 'diapers', 'chard', 'wine']),
#     frozenset(['OJ', 'soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'OJ', 'soy milk', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'OJ', 'soy milk', 'diapers'])
#     ]
#




###########################################################
###########################################################


def scan_orders(i_orders, i_itemSet, i_minSupport):

   #
   #  An empty dictionary, used to hold counts per
   #  item(s). And items could be a single item, or 
   #  2 or more items as generated outside of this
   #  function.
   #
   #  This function calculates 'support'. Eg., what
   #  percent of orders contain this item. As such,
   #  we always pass the complete orders list.
   #
   l_itemAndCount = {}

   for l_order in i_orders:
      for l_item in i_itemSet:
         #
         #  i_itemSet is a list of items; possibly
         #  single items, possibly groups of 2 or
         #  more items.
         #
         #  Why ?
         #
         #  Whoever calls this function has pruned
         #  the i_itemSet to contain only those items
         #  we have interest in.
         #
         #  Eg., if no one ever buys 'prunes', then
         #  the liklihood someone buys 'prunes' and
         #  'chocolate' is also low.
         #
         if l_item.issubset(l_order):
            #
            #  This order has an item in our watch
            #  list.
            #
            #  If we've never seen this item, add it
            #  to our result with a count of 1. Else
            #  we have the item, increment the count
            #  by 1.
            #
            if (l_itemAndCount.has_key(l_item)):
               l_itemAndCount[l_item] += 1
            else:
               l_itemAndCount[l_item]  = 1

   #
   #  Here we have the counts of specific item(s).
   #  Calculate final responses.
   #
   r_itemsMatching       = []
   r_itemsAllWithSupport = {}
      #
   l_numOrders = float(len(i_orders))


   #
   #  Score our result set, prepare return values.
   #
   for l_item in l_itemAndCount:
      l_support = l_itemAndCount[l_item] / l_numOrders
         #
      if (l_support >= i_minSupport):
         r_itemsMatching.insert(0, l_item)
      r_itemsAllWithSupport[l_item] = l_support

   return r_itemsMatching, r_itemsAllWithSupport


#
#  Input, pass 1:
#     All orders (same for each pass)
#     [
#     set(['lettuce', 'soy milk']),
#     set(['lettuce', 'chard', 'diapers', 'wine']),
#     set(['OJ', 'soy milk', 'diapers', 'wine']),
#     set(['lettuce', 'soy milk', 'diapers', 'wine']),
#     set(['lettuce', 'soy milk', 'diapers', 'OJ'])
#     ]
#
#     Specific item(s) to measure 'support' for
#     [
#     frozenset(['OJ']),
#     frozenset(['chard']),
#     frozenset(['diapers']),
#     frozenset(['lettuce']),
#     frozenset(['soy milk']),
#     frozenset(['wine'])
#     ]
#
#     Requested 'l_confidence', same for each pass
#     0.08 
#
#  Output:
#     All single items
#     [
#     frozenset(['chard']),
#     frozenset(['wine']),
#     frozenset(['diapers']),
#     frozenset(['soy milk']),
#     frozenset(['lettuce']),
#     frozenset(['OJ'])
#     ]
#
#     With 5 orders, and a requested confidence of
#     0.08, all items pass
#     {
#     frozenset(['OJ']): 0.4,
#     frozenset(['lettuce']): 0.8,
#     frozenset(['soy milk']): 0.8,
#     frozenset(['diapers']): 0.8,
#     frozenset(['wine']): 0.6,
#     frozenset(['chard']): 0.2
#     }
#

#
#  Input, pass 2:
#     ( Same input 1, and 3)
#
#     15 (count) possible item pairs, only 2 pairs did 
#     not occur in 5 orders:
#        soy milk, chard
#        and
#        chard, OJ
#     [
#     frozenset(['chard', 'wine']),
#     frozenset(['chard', 'diapers']),
#     frozenset(['soy milk', 'chard']),
#     frozenset(['lettuce', 'chard']),
#     frozenset(['chard', 'OJ']),
#     frozenset(['diapers', 'wine']),
#     frozenset(['soy milk', 'wine']),
#     frozenset(['lettuce', 'wine']),
#     frozenset(['OJ', 'wine']),
#     frozenset(['soy milk', 'diapers']),
#     frozenset(['lettuce', 'diapers']),
#     frozenset(['diapers', 'OJ']),
#     frozenset(['lettuce', 'soy milk']),
#     frozenset(['soy milk', 'OJ']),
#     frozenset(['lettuce', 'OJ'])
#     ]
#
#  13 item pairs happened 0.08 or more times
#
#  Output:
#     [
#     frozenset(['soy milk', 'diapers']),
#     frozenset(['lettuce', 'wine']),
#     frozenset(['lettuce', 'OJ']),
#     frozenset(['OJ', 'wine']),
#     frozenset(['soy milk', 'OJ']),
#     frozenset(['lettuce', 'soy milk']),
#     frozenset(['lettuce', 'chard']),
#     frozenset(['diapers', 'wine']),
#     frozenset(['chard', 'diapers']),
#     frozenset(['diapers', 'OJ']),
#     frozenset(['soy milk', 'wine']),
#     frozenset(['lettuce', 'diapers']),
#     frozenset(['chard', 'wine'])
#     ]
#
#     {
#     frozenset(['chard', 'wine']): 0.2,
#     frozenset(['lettuce', 'diapers']): 0.6,
#     frozenset(['soy milk', 'wine']): 0.4,
#     frozenset(['diapers', 'OJ']): 0.4,
#     frozenset(['chard', 'diapers']): 0.2,
#     frozenset(['diapers', 'wine']): 0.6,
#     frozenset(['lettuce', 'chard']): 0.2,
#     frozenset(['lettuce', 'soy milk']): 0.6,
#     frozenset(['soy milk', 'OJ']): 0.4,
#     frozenset(['OJ', 'wine']): 0.2,
#     frozenset(['lettuce', 'OJ']): 0.2,
#     frozenset(['lettuce', 'wine']): 0.4,
#     frozenset(['soy milk', 'diapers']): 0.6
#     }
#

#
#  Input, pass 3:
#     ( Same input 1, and 3)
#
#     15 (count) possible item triplets, only 3 pairs did 
#     not occur in 5 orders:
#        lettuce, OJ, wine
#        lettuce, OJ, chard
#        lettuce, soy milk, chard
#     [
#     frozenset(['soy milk', 'diapers', 'OJ']),
#     frozenset(['soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'OJ', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'wine']),
#     frozenset(['lettuce', 'chard', 'wine']),
#     frozenset(['lettuce', 'diapers', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'OJ']),
#     frozenset(['lettuce', 'OJ', 'chard']),
#     frozenset(['lettuce', 'OJ', 'diapers']),
#     frozenset(['soy milk', 'OJ', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'chard']),
#     frozenset(['lettuce', 'soy milk', 'diapers']),
#     frozenset(['lettuce', 'chard', 'diapers']),
#     frozenset(['OJ', 'diapers', 'wine']),
#     frozenset(['wine', 'chard', 'diapers'])
#     ]
#
#   Output:
#      [
#      frozenset(['lettuce', 'chard', 'wine']),
#      frozenset(['wine', 'chard', 'diapers']),
#      frozenset(['soy milk', 'diapers', 'wine']),
#      frozenset(['lettuce', 'diapers', 'wine']),
#      frozenset(['lettuce', 'soy milk', 'wine']),
#      frozenset(['lettuce', 'OJ', 'diapers']),
#      frozenset(['OJ', 'diapers', 'wine']),
#      frozenset(['soy milk', 'OJ', 'wine']),
#      frozenset(['lettuce', 'soy milk', 'OJ']),
#      frozenset(['lettuce', 'chard', 'diapers']),
#      frozenset(['soy milk', 'diapers', 'OJ']),
#      frozenset(['lettuce', 'soy milk', 'diapers'])
#      ]
#
#      {
#      frozenset(['lettuce', 'soy milk', 'diapers']): 0.4,
#      frozenset(['soy milk', 'diapers', 'OJ']): 0.4,
#      frozenset(['lettuce', 'chard', 'diapers']): 0.2,
#      frozenset(['lettuce', 'soy milk', 'OJ']): 0.2,
#      frozenset(['soy milk', 'OJ', 'wine']): 0.2,
#      frozenset(['OJ', 'diapers', 'wine']): 0.2,
#      frozenset(['lettuce', 'OJ', 'diapers']): 0.2,
#      frozenset(['lettuce', 'soy milk', 'wine']): 0.2,
#      frozenset(['lettuce', 'diapers', 'wine']): 0.4,
#      frozenset(['soy milk', 'diapers', 'wine']): 0.4,
#      frozenset(['wine', 'chard', 'diapers']): 0.2,
#      frozenset(['lettuce', 'chard', 'wine']): 0.2
#      }
#

#
#  Input, pass 4:
#     ( Same input 1, and 3)
#
#
#     5 (count) possible item quatros, only 1 pair did 
#     not occur in 5 orders:
#        lettuce, OJ, soy milk, wine
#     [
#     frozenset(['lettuce', 'diapers', 'chard', 'wine']),
#     frozenset(['OJ', 'soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'OJ', 'soy milk', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'OJ', 'soy milk', 'diapers'])
#     ]
#
#  Output:
#     [
#     frozenset(['OJ', 'soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'diapers', 'chard', 'wine']),
#     frozenset(['lettuce', 'OJ', 'soy milk', 'diapers'])
#     ]
#
#     {
#     frozenset(['lettuce', 'OJ', 'soy milk', 'diapers']): 0.2,
#     frozenset(['lettuce', 'diapers', 'chard', 'wine']): 0.2,
#     frozenset(['lettuce', 'soy milk', 'diapers', 'wine']): 0.2,
#     frozenset(['OJ', 'soy milk', 'diapers', 'wine']): 0.2
#     }




###########################################################
###########################################################


#
#  This function acts as a driver of sorts, calling:
#
#     create_itemSet(i_orders)
#        Take the orders list and generate a list of
#        single unique items. This list is used to
#        generate pairs of items, triples or items,
#        Etcetera.
#
#     generate_itemPairs(l_itemsMatching, l_offset)
#        Given a set of item pairs that have been
#        found to have a given 'support', generate
#        the further pairs. Eg., If wine/diapers
#        has a high enough support, generate the
#        next possible item wine/diapers/xxx, where
#        xxx comes from the overall item list.
#        
#        l_offset instructs this function where to
#        join the list for generating the next (pairs).
#
#      scan_orders(l_ordersAsSet, l_candidateItems,
#         i_minSupport)
#
#         l_ordersAsSet is the list of all orders.
#     
#         l_candidateItems is the list if single
#         paired, and higher items (3's, 4's, ..)
#         that received a given 'support' or higher.
#     

def apriori(i_orders, i_minSupport):

   #
   #  Create a list of single unique items from this
   #  list of orders.
   #
   l_itemSet = create_itemSet(i_orders)

   #
   #  Convert the list of orders into a set.
   #     [ set(['eggs']), set(['milk']), ..
   #
   l_ordersAsSet  = map(set, i_orders)

   #
   #  Return just the items of interest (high level of
   #  'support' for just single items.
   #
   l_itemsMatching, r_itemsAllWithSupport = scan_orders(
      l_ordersAsSet, l_itemSet, i_minSupport)

   r_itemsMatching = [l_itemsMatching]
      #
   l_offset   = 2

   
   #
   #  Above we calculated items of interest for just
   #  single items.
   #
   #  This loop, and its funny array indexing is merely
   #  to generate (and then calculate the 'support' for)
   #  items pairs, items threes, fours, ..
   #
   #  generate_itemPairs() is new, because we did not 
   #  need more than item singles.
   #
   #  Otherwise, scan_orders() is exactly the same.
   #  
   while (len(r_itemsMatching[l_offset - 2]) > 0):
         #
      l_candidateItems = generate_itemPairs(
         r_itemsMatching[l_offset-2], l_offset)
            #
      l_itemMatching, l_itemWithSupport = scan_orders(
         l_ordersAsSet, l_candidateItems, i_minSupport)
            #
      #
      #  r_itemsAllWithSupport contains all items, thus
      #  we do an array update.
      #
      r_itemsAllWithSupport.update(l_itemWithSupport)
      #
      #  r_itemsMatching contains only items we have seen, 
      #  those we have seen, thus we do an append.
      #
      r_itemsMatching.append(l_itemMatching)
         #
      l_offset += 1

   return r_itemsMatching, r_itemsAllWithSupport


#
#  Input:
#     [
#     ['soy milk', 'lettuce'],
#     ['lettuce', 'diapers', 'wine', 'chard'],
#     ['soy milk', 'diapers', 'wine', 'OJ'],
#     ['lettuce', 'soy milk', 'diapers', 'wine'],
#     ['lettuce', 'soy milk', 'diapers', 'OJ']
#     ]
#     0.08
#  Output:
#     [
#     [
#     frozenset(['chard']),
#     frozenset(['wine']),
#     frozenset(['diapers']),
#     frozenset(['soy milk']),
#     frozenset(['lettuce']),
#     frozenset(['OJ'])
#     ],
#     [
#     frozenset(['soy milk', 'diapers']),
#     frozenset(['lettuce', 'wine']),
#     frozenset(['lettuce', 'OJ']),
#     frozenset(['OJ', 'wine']),
#     frozenset(['soy milk', 'OJ']),
#     frozenset(['lettuce', 'soy milk']),
#     frozenset(['lettuce', 'chard']),
#     frozenset(['diapers', 'wine']),
#     frozenset(['chard', 'diapers']),
#     frozenset(['diapers', 'OJ']),
#     frozenset(['soy milk', 'wine']),
#     frozenset(['lettuce', 'diapers']),
#     frozenset(['chard', 'wine'])
#     ],
#     [
#     frozenset(['lettuce', 'chard', 'wine']),
#     frozenset(['wine', 'chard', 'diapers']),
#     frozenset(['soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'diapers', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'wine']),
#     frozenset(['lettuce', 'OJ', 'diapers']),
#     frozenset(['OJ', 'diapers', 'wine']),
#     frozenset(['soy milk', 'OJ', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'OJ']),
#     frozenset(['lettuce', 'chard', 'diapers']),
#     frozenset(['soy milk', 'diapers', 'OJ']),
#     frozenset(['lettuce', 'soy milk', 'diapers'])
#     ],
#     [
#     frozenset(['OJ', 'soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'soy milk', 'diapers', 'wine']),
#     frozenset(['lettuce', 'diapers', 'chard', 'wine']),
#     frozenset(['lettuce', 'OJ', 'soy milk', 'diapers'])
#     ]
#
#     {
#     frozenset(['chard', 'wine']): 0.2,
#     frozenset(['lettuce', 'soy milk', 'diapers']): 0.4,
#     frozenset(['OJ']): 0.4,
#     frozenset(['soy milk', 'diapers', 'OJ']): 0.4,
#     frozenset(['lettuce', 'soy milk', 'OJ']): 0.2,
#     frozenset(['diapers']): 0.8,
#     frozenset(['lettuce', 'OJ', 'diapers']): 0.2,
#     frozenset(['chard', 'diapers']): 0.2,
#     frozenset(['diapers', 'wine']): 0.6,
#     frozenset(['lettuce', 'diapers', 'chard', 'wine']): 0.2,
#     frozenset(['lettuce', 'soy milk', 'diapers', 'wine']): 0.2,
#     frozenset(['lettuce', 'soy milk', 'wine']): 0.2,
#     frozenset(['OJ', 'soy milk', 'diapers', 'wine']): 0.2,
#     frozenset(['OJ', 'wine']): 0.2,
#     frozenset(['wine']): 0.6,
#     frozenset(['lettuce', 'OJ']): 0.2,
#     frozenset(['wine', 'chard', 'diapers']): 0.2,
#     frozenset(['lettuce', 'chard', 'diapers']): 0.2,
#     frozenset(['lettuce', 'chard', 'wine']): 0.2,
#     frozenset(['OJ', 'diapers', 'wine']): 0.2,
#     frozenset(['lettuce', 'diapers']): 0.6,
#     frozenset(['soy milk', 'wine']): 0.4,
#     frozenset(['diapers', 'OJ']): 0.4,
#     frozenset(['lettuce']): 0.8,
#     frozenset(['lettuce', 'OJ', 'soy milk', 'diapers']): 0.2,
#     frozenset(['soy milk']): 0.8,
#     frozenset(['soy milk', 'diapers', 'wine']): 0.4,
#     frozenset(['lettuce', 'diapers', 'wine']): 0.4,
#     frozenset(['lettuce', 'chard']): 0.2,
#     frozenset(['lettuce', 'soy milk']): 0.6,
#     frozenset(['soy milk', 'OJ']): 0.4,
#     frozenset(['chard']): 0.2,
#     frozenset(['lettuce', 'wine']): 0.4,
#     frozenset(['soy milk', 'OJ', 'wine']): 0.2,
#     frozenset(['soy milk', 'diapers']): 0.6
#     }
#


  

###########################################################
###########################################################
###########################################################
###########################################################


#
#  These next 3 functions calulcate the association rules.
#  Eg., persons who buy pasta buy wine x% of the time.
#
#  Association rules can only be calculated on orders with
#  2 or more items.
#
#  Definitions:
#
#     'frequent item set', a single or set of items
#        which are purchased frequently. this frequency
#        is reflected in the 'support' value, defined
#        below.
#
#     'support' = count-of-item-set / count-of-orders
#        Eg., if wine occurs in 3 orders, and there
#           are 5 orders total, the support for wine is 
#           60%    ( 3 / 5)
#
#     'confidence' = support (A,B) / support (A)
#        Eg., if wine,pasta occurs in 3 of 5 orders,
#           and wine occurs in 4 of 5 orders, then
#              (3/5) / (4/5) == 60% / %80 == 75%
#        Our confidence that a wine buyer will buy
#        pasta is 75%.
#
 
def gen_assocRules(i_itemsMatching, i_itemsAllWithSupport,
      i_minConf):  

   r_ruleList = []

   #
   #  Only get the sets with two or more items in an order.
   #
   #  Why does the first for-loop start with 1 ? Because
   #  that index of i_itemsMatching contains pairs of items.
   #
   for i in range(1, len(i_itemsMatching)):
      for l_itemSet in i_itemsMatching[i]:

         #
         #  We need the l_itemSet as an indexable
         #  data structure, hence frozen.
         #
         l_itemSetFrozen = [frozenset([l_item]) for
            l_item in l_itemSet]
               #
         if (i > 1):
            #
            #  This block will be true for triplets of items
            #  and higher.
            #
            #  This block does some optimizations before 
            #  calling do_calcConf()
            #
            do_calcRule(l_itemSet, l_itemSetFrozen,
               i_itemsAllWithSupport, r_ruleList, i_minConf)
         else:
            #
            #  This block will be true for pairs of items.
            #
            do_calcConf(l_itemSet, l_itemSetFrozen,
               i_itemsAllWithSupport, r_ruleList, i_minConf)

   return r_ruleList         


      ###############################################

#
#  Calculate the confidence.
#
def do_calcConf(i_itemSet, i_itemSetFrozen, i_itemsAllWithSupport,
      i_ruleList, i_minConf):

   #
   #  Create new list to return.
   #
   r_prunedItemSets = [] 

   for l_itemSetOfConseq in i_itemSetFrozen:
      l_confidence = ( i_itemsAllWithSupport[i_itemSet] /
            i_itemsAllWithSupport[ i_itemSet -
            l_itemSetOfConseq ] )
      if l_confidence >= i_minConf: 
         i_ruleList.append((i_itemSet-l_itemSetOfConseq,
            l_itemSetOfConseq, l_confidence))
         r_prunedItemSets.append(l_itemSetOfConseq)

   return r_prunedItemSets


      ###############################################

#
#  Merges itemsets to those with 2 or more items only.
#
def do_calcRule(i_itemSet, i_itemSetFrozen, i_itemsAllWithSupport,
      i_ruleList, i_minConf):

   i = len(i_itemSetFrozen[0])

   #
   #  Try further merging.
   #
   if (len(i_itemSet) > (i + 1)):
      l_allPossRules = generate_itemPairs(i_itemSetFrozen, i+1)
         #
      l_allPossRules = do_calcConf(i_itemSet, l_allPossRules,
         i_itemsAllWithSupport, i_ruleList, i_minConf)
            #   
            #  Need at least two sets to merge
            #
      if (len(l_allPossRules) > 1):
         do_calcRule(i_itemSet, l_allPossRules,
            i_itemsAllWithSupport, i_ruleList, i_minConf)




###########################################################
###########################################################


#
#  Sample orders ..
#
def load_orders():

   return [
      [ "soy milk" , "lettuce"                        ],
      [ "lettuce"  , "diapers"  , "wine"    , "chard" ],
      [ "soy milk" , "diapers"  , "wine"    , "OJ"    ],
      [ "lettuce"  , "soy milk" , "diapers" , "wine"  ],
      [ "lettuce"  , "soy milk" , "diapers" , "OJ"    ]
      ]




###########################################################


m_orders = load_orders()
   

l_itemsMatching, l_itemsAllWithSupport = apriori(
   m_orders, 0.08)


m_rules = gen_assocRules(l_itemsMatching,
   l_itemsAllWithSupport, 0.25)

print ""
print ""
print "Contents of m_rules at 0.25"
print ""
for l_rule in m_rules:
   print "Association rule:"
   for l_item in l_rule[0]:
      print "    " + str([l_item])
         #
   print "  -------->"
         #
   for l_item in l_rule[1]:
      print "    " + str([l_item])
   print "  Conf: %f" % l_rule[2]
   print ""








            
 
 












