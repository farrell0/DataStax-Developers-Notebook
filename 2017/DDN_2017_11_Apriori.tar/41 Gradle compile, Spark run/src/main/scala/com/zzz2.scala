

package com


import org.apache.spark.{SparkConf, SparkContext}


object zzz2 {

   def main(args: Array[String]) {

      val sc = new SparkContext(new SparkConf().setAppName("zzz2"))

      println("Goodbye Hollywood !")

      sc.stop()

   }

}



