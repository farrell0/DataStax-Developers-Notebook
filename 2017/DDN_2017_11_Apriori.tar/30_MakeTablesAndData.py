

#
#  DSE driver installed via,
#
#     pip install dse-driver
#

#
#  Batch program to create db, table, and load data.
#
#  The data is 'association rules' on grocery. Eg., folks
#  who buy pasta also buy pasta sauce.
#
#  All is meant to support a select similar to,
#
#     select toSell, confidence from t5
#     where toBuy = 'wine' order by confidence;
#

#
#  Assumptions below;
#
#  .  This program expects a functioning DSE at 127.0.0.1.
#
#  .  This program only needs DSE core, nothing more.
#




############################################################


#
#  Imports.
#

from dse.cluster import Cluster

import csv




############################################################
############################################################


#
#  Setting up the database, and load data from CSV.
#


def createAndLoad_table():

   print ""
   print ""
   print "Working .."


   l_cluster = Cluster(
      contact_points=['127.0.0.1']
      )
   l_session = l_cluster.connect()
   
   
   l_stmt =                                                 \
      "DROP KEYSPACE IF EXISTS ks_11;                   "
   l_resu = l_session.execute(l_stmt)
   print "  Drop keyspace .."
      #
   l_stmt =                                                 \
      "CREATE KEYSPACE ks_11 WITH REPLICATION =         " + \
      "{'class': 'SimpleStrategy',                      " + \
      "   'replication_factor': 1};                     "
   l_resu = l_session.execute(l_stmt)
   print "  Create keyspace .."


   l_stmt =                                                 \
      "CREATE TABLE ks_11.association_rules             " + \
      "   (                                             " + \
      "   toBuy             TEXT,                       " + \
      "   toSell            TEXT,                       " + \
      "   confidence        FLOAT,                      " + \
      "PRIMARY KEY ((toBuy), confidence, toSell))       " + \
      "WITH CLUSTERING ORDER BY                         " + \
      "   (confidence DESC, toSell ASC);"
   l_resu = l_session.execute(l_stmt)
   print "  Create table .."


   l_stmt =                                                 \
      "INSERT INTO ks_11.association_rules              " + \
      "   (toBuy, toSell, confidence)                   " + \
      "VALUES ( %s, %s, %s )                            "
         #
   l_cntr = 0
   print "  Inserting data .."

   with open('12_association_rules.csv') as l_file:
      l_rows =  csv.reader(l_file, delimiter=',')
         #
      for l_row in l_rows:
         l_cntr += 1
            #
         l_session.execute(l_stmt, (str.rstrip(l_row[0]),
            str.rstrip(l_row[1]), float(l_row[2])))
   

   l_session.shutdown()


   print ""
   print "Rows loaded: " + str(l_cntr)
   print ""
   print ""




############################################################
############################################################


#
#  The program main.
#

if __name__=='__main__':
   createAndLoad_table()








