

#
#  From,
#     https://spark.apache.org/docs/1.6.0/mllib-frequent-pattern-mining.html
#     http://spark.apache.org/docs/2.0.2/api/python/_modules/pyspark/mllib/fpm.html

#
#  The Spark MLlib/Apriori library has methods to calculate
#  support. This same library is not complete. and does not
#  include methods to calculate association rules. There is
#  a Jira for this, and they are working on it, but ..
#
#     https://issues.apache.org/jira/browse/SPARK-14501
#

from pyspark.mllib.fpm import FPGrowth
from pyspark import SparkContext




###########################################################
###########################################################


sc = SparkContext()


l_datafile = sc.textFile("10_grocery.csv")
   #
l_orders = l_datafile.map(lambda line: line.strip().split(','))


l_model = FPGrowth.train(l_orders, minSupport=0.01, numPartitions=1)


#
# l_results is of type: <class 'collections.FreqItemset'>
#
l_results = l_model.freqItemsets().collect()



for l_result in l_results:
   print str(l_result[0]) + " " + str(float(l_result[1]) / 100)



#  From Spark,
#     [u'whole milk'] 0.2513                                                          
#     [u'other vegetables'] 0.1903
#     [u'rolls/buns'] 0.1809
#  
#  From pure Python,
#     frozenset(['whole milk']) 0.255516014235
#     frozenset(['other vegetables']) 0.193492628368
#     frozenset(['rolls/buns']) 0.183934926284
   







