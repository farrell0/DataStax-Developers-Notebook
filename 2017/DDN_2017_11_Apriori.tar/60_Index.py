

#
#  Simple UI to show 'customer who bought (x) ..
#




#############################################################
## Imports ##################################################


#
#  Flask is our Python based Web server.
#
from flask import Flask, render_template, request, jsonify

#
#  We use this to use a directory other than the default for
#  Flask CSS files and related.
#
import os

#
#  Used to sort our return list to Tab 5, the HTML table.
#  Solr sorts the data by its ranking. we want it sorted
#  by a given column. No worries; its only 10 rows and 
#  we really should be using a SASI index.
#
from operator import itemgetter

#
#  We use threading because we concurrently serve a Web
#  site and read from a database.
#
import threading 
from threading import Thread
   
#
#  We sleep in the thread to avoid destroying the CPU on
#  this laptop hosted virtual machine.
#
import time

#
#  The DataStax Enterpise database connectivity driver.
#
from dse.cluster import Cluster




#############################################################
## Inits, Opens, and Sets ###################################


#
#  Instantiate flask object
#
m_app = Flask(__name__)


#  
#  Set flask defaults for locating files
#
m_templateDir = os.path.abspath("45_views" )
m_staticDir   = os.path.abspath("44_static")
   #
m_app.template_folder = m_templateDir
m_app.static_folder   = m_staticDir


      ################################################


#
#  Initialize modular variables. These variable represent 
#  the default/initial settings of our HTML radio buttons.
#
m_gender   = "M"
m_century  = "1900"


      ################################################


#
#  Open the database handle used by a given page handler.
#
try:
   m_cluster = Cluster(
      contact_points=['127.0.0.1']
      )
   m_session2 = m_cluster.connect()
   print ""
   print "Success: Connected to Cassandra cluster."
   print ""
except:
   print ""
   print "Error: Unable to connect to Cassandra at localhost."
   print ""
   exit(4)




#############################################################
## Our Web pages (page handlers) ############################


#
#  This is our main page.
#
@m_app.route('/')
def overview_tab():
   return render_template("60_Index.html")


      ################################################


#
#  This page responds to our requests for all text box
#  type aheads.
#
@m_app.route("/search/<string:l_box>")
def process(l_box):
   global m_myClass
      #
   global m_gender
   global m_century

   l_query = request.args.get('query')

   if (l_box == 'text1'):
      # do some stuff to open your names text file
      # do some other stuff to filter
      # put suggestions in this format...
      l_suggestions = [
         {'value': 'Space Trucking'},
         {'value': 'China Grove'   },
         {'value': 'Hotel Colorado'},
         {'value': 'Freebird',     }]
   if (l_box == 'text2'):
      l_suggestions = m_myClass.get_suggestions(l_query,
         m_gender, m_century)

   return jsonify({"suggestions": l_suggestions})


      ################################################


#
#  This (page) receives our changes to the radio buttons
#  and sets state for our query filters.
#
#  This function/page uses Ajax and jQuery. All of the 
#  work is done in a thread below, which binds th results
#  to a variable.
#
@m_app.route('/_doRadio')
def do_radio():
   global m_gender
   global m_century

   m_gender   = request.args.get("h_gender")
   m_century  = request.args.get("h_century")

   return jsonify()


      ################################################


#
#  This page runs TAB 6, our 'persons who bought' page
# 
@m_app.route('/_exec_tab5')
def exec_tab5():
   global m_session2

   #
   #  Our unsorted list of dictionaries. Each entry is
   #  a column response from a database query.
   #
   l_response = []

   l_predicate = request.args.get('h_predicate')
      #
   l_query =                                         \
      "SELECT tobuy, tosell, confidence          " + \
      "FROM ks_11.association_rules              " + \
      "WHERE tobuy = '"                            + \
      str.rstrip(str(l_predicate))                 + \
      "' LIMIT 60;                               "

   try:
      l_results = m_session2.execute(l_query)
      for l_result in l_results:
         l_dict = { 'toBuy' : l_result[0],  
            'toSell' : l_result[1], 'confidence' : l_result[2] }
         l_response.append( l_dict)
   except:
      pass

   #
   #  Solr sorted this list for us, but we want it sorted
   #  by the confidence column.
   #
   r_response = sorted(l_response, key=itemgetter(
      'confidence'), reverse=True) 
         #
   return jsonify(r_response)




############################################################
############################################################


#
#  A class we run as an async thread. 
# 
#  This class takes a query predicate and returns an array
#  of satisfying rows from our Cassandra table.
#

class my_class(Thread):
   m_queryString = "__Z"
   m_session = object()
      #
   m_queryResults = []


   #
   #  The constructor; set modular variables.
   #
   def __init__(self):
      Thread.__init__(self)
      self.daemon = True
         #
      l_cluster = Cluster(
         contact_points=['127.0.0.1']
         )
      self.m_session = l_cluster.connect()
         #
      self.start()

   #
   #  Start the thread.
   #
   def run(self):
      while True:
         time.sleep(1)

   #
   #  This getter() returns results to the visual control.
   #
   #  This is where we run the actual database query.
   #
   def get_suggestions(self, l_queryString, l_gender,
         l_century):

      self.m_queryString = l_queryString
      del self.m_queryResults[:]
         #
      #
      #  This is the SQL syntax to run a text analytics
      #  query.
      #
      l_query =                                     \
         "select name from k_at.t4 " +              \
         "where solr_query = '{ \"q\" : \"(name:" + \
         str.rstrip(str(self.m_queryString)) +      \
         "* OR name:" +                             \
         str.rstrip(str(self.m_queryString)) +      \
         "~2) AND gender:" +                        \
         str.rstrip(str(l_gender)) +                \
         " AND century:" +                          \
         str.rstrip(str(l_century)) +               \
         "\" }' limit 10;"
      l_results = self.m_session.execute(l_query)
         #
      for l_result in l_results:
            #
         l_docu = { 'value' : l_result.name }
         self.m_queryResults.append(l_docu)
            #
      return self.m_queryResults


#
#  This query we run above is similar to,
#
#   select name from k_at.t4 where solr_query =
#      '{ "q" : "(name:D* OR name:DAVE~1^8) AND
#         gender:M AND century:2000" }' limit 10;
#




#############################################################
#############################################################


#
#  And then running our Web site proper.
#
if __name__=='__main__':
   
   m_myClass = my_class()
      #
   m_app.run(host = "localhost", port = int("8081"), debug=True)







