

//
//  This job that had to be submitted via absolute pathname.
//


package com


import org.apache.spark.{SparkConf, SparkContext}

import com.datastax.spark.connector._
import com.datastax.spark.connector.cql.CassandraConnector


object zzz3 {

   def main(args: Array[String]) {

      val sc = new SparkContext(new SparkConf().setAppName("zzz3"))
      

      val l_q1 = sc.cassandraTable("ks_11", "association_rules").select("tobuy", "confidence", "tosell")

      val l_q2 = l_q1.where("tobuy = 'soy-milk'")

      val l_resultsRDD = l_q2.collect.foreach(println)

      l_q2.collect.foreach(println)    


      sc.stop()

   }

}

